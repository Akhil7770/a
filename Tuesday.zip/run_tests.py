#!/usr/bin/env python3
"""
Test runner script for the cost estimator service.
"""

import sys
import os
import subprocess
import argparse

def run_tests(test_type=None, verbose=False, coverage=False):
    """Run the tests with the specified options."""
    
    # Add the app directory to the Python path
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))
    
    # Build the pytest command
    cmd = ["python3", "-m", "pytest"]
    
    if verbose:
        cmd.append("-v")
    
    if coverage:
        cmd.extend(["--cov=app", "--cov-report=term-missing", "--cov-report=html"])
    
    if test_type:
        cmd.append(f"-m {test_type}")
    
    # Add the tests directory
    cmd.append("tests/")
    
    print(f"Running command: {' '.join(cmd)}")
    print("=" * 60)
    
    try:
        result = subprocess.run(cmd, check=False)
        return result.returncode
    except Exception as e:
        print(f"Error running tests: {e}")
        return 1

def main():
    """Main function to parse arguments and run tests."""
    parser = argparse.ArgumentParser(description="Run tests for the cost estimator service")
    parser.add_argument("--type", "-t", choices=["unit", "integration", "api", "repository", "service"], 
                       help="Type of tests to run")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    parser.add_argument("--coverage", "-c", action="store_true", help="Run with coverage")
    parser.add_argument("--all", "-a", action="store_true", help="Run all tests")
    
    args = parser.parse_args()
    
    if args.all:
        print("Running all tests...")
        return run_tests(verbose=args.verbose, coverage=args.coverage)
    elif args.type:
        print(f"Running {args.type} tests...")
        return run_tests(test_type=args.type, verbose=args.verbose, coverage=args.coverage)
    else:
        print("Running all tests...")
        return run_tests(verbose=args.verbose, coverage=args.coverage)

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code) 