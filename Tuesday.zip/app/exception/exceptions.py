class BadRequestException(Exception):
    pass


class RateNotFoundException(Exception):
    """Exception raised when a rate cannot be found for the given criteria."""

    def __init__(
        self,
        message: str = "Rate not found for the given criteria",
        rate_criteria: dict | None = None,
    ):
        self.message = message
        self.rate_criteria = rate_criteria or {}
        super().__init__(self.message)


class ProviderNotFoundException(Exception):

    def __init__(
        self,
        message: str = "Provider not found for the given criteria",
        provider_criteria: dict | None = None,
    ):
        self.message = message
        self.provider_criteria = provider_criteria or {}
        super().__init__(self.message)


class BenefitsNotFoundException(Exception):
    """Exception raised when benefits cannot be found for the given request."""

    def __init__(
        self,
        message: str = "Benefits not found for the given request",
        benefit_request: dict | None = None,
    ):
        self.message = message
        self.benefit_request = benefit_request or {}
        super().__init__(self.message)


class BenefitsMemberNotFoundException(Exception):
    """Exception raised when given member ID cannot be found by benefits api."""

    def __init__(
        self,
        message: str = "Member not found by benefits api",
    ):
        self.message = message
        super().__init__(self.message)


class BenefitsNotMatchingException(Exception):
    """Exception raised when benefits cannot be found for the given request."""

    def __init__(
        self,
        message: str = "No matching selected benefits",
        benefit_request: dict | None = None,
    ):
        self.message = message
        self.benefit_request = benefit_request or {}
        super().__init__(self.message)


class AccumulatorNotFoundException(Exception):
    """Exception raised when accumulator information cannot be found for the given request."""

    def __init__(
        self,
        message: str = "Accumulator not found for the given request",
        accumulator_request: dict | None = None,
    ):
        self.message = message
        self.accumulator_request = accumulator_request or {}
        super().__init__(self.message)


class AccumulatorMemberNotFoundException(Exception):
    """Exception raised when given member ID cannot be found by accumulator api."""

    def __init__(
        self,
        message: str = "Member not found by accumulator api",
        accumulator_request: dict | None = None,
    ):
        self.message = message
        self.accumulator_request = accumulator_request or {}
        super().__init__(self.message)


class InsuranceContextException(Exception):
    """Exception raised when insurance context information cannot be found for the given request."""

    def __init__(
        self,
        message: str = "Insurance context error for the given request",
        error_code: str | None = None,
        error_message: str | None = None,
    ):
        self.message = message
        self.error_code = error_code
        self.error_message = error_message
        super().__init__(self.message)


class CircuitBreakerOpenException(Exception):
    """Exception raised when circuit breaker is open and service is unavailable."""

    def __init__(
        self,
        message: str = "Service temporarily unavailable due to circuit breaker being open",
        service_name: str | None = None,
        circuit_breaker_state: str = "open",
        service_type: str | None = None,
    ):
        self.message = message
        self.service_name = service_name
        self.circuit_breaker_state = circuit_breaker_state
        self.service_type = service_type
        super().__init__(self.message)
