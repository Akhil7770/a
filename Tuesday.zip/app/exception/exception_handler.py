from fastapi import FastAPI, Request
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from typing import Any, Dict

from app.exception.exceptions import (
    RateNotFoundException,
    BenefitsNotFoundException,
    AccumulatorNotFoundException,
    AccumulatorMemberNotFoundException,
    InsuranceContextException,
    BenefitsNotMatchingException,
    BenefitsMemberNotFoundException,
)
from app.core.logger import logger


def produce_response_content(exc: Any) -> Dict[str, Any]:
    logger.error(f"Exception: {str(exc)}")
    response_content = {}
    response_content["correlationId"] = (
        "069d197a-1e14-453f-8cf4-63f74eb626ff"  # correlationId should be transactionId
    )
    response_content["type"] = "https://www.rfc-editor.org/rfc/rfc7231#section-6.5.4"
    response_content["title"] = "Error"
    response_content["status"] = 500
    response_content["detail"] = "Unknown error"
    response_content["message"] = "Unknown error"
    return response_content


# message from custom benefits goes into detail field of json response


async def validation_exception_handler(request: Request, exc: Any) -> JSONResponse:
    """Handle validation errors and return standardized format."""

    # Build error message from validation errors
    error_messages = []
    for error in exc.errors():
        field_path = ".".join(
            str(loc) for loc in error["loc"][1:]
        )  # Skip 'body' from location
        error_type = error["type"]
        error_msg = error["msg"]

        if error_type == "missing":
            error_messages.append(f"Missing required field: {field_path}")
        elif error_type == "string_too_short":
            min_length = error.get("ctx", {}).get("min_length", 1)
            error_messages.append(
                f"Field '{field_path}' must have at least {min_length} character(s)"
            )
        elif error_type == "json_invalid":
            # Handle JSON parsing errors
            ctx_error = error.get("ctx", {}).get("error", "Invalid JSON format")
            error_messages.append(f"Invalid JSON format: {ctx_error}")
        else:
            error_messages.append(f"Field '{field_path}': {error_msg}")

    # Create standardized error response
    response_content = produce_response_content(exc)
    response_content["detail"] = "; ".join(error_messages)
    response_content["title"] = "Validation Error"
    response_content["message"] = "One or more validation errors occurred"
    response_content["status"] = 400

    return JSONResponse(content=response_content, status_code=400)


def rate_not_found_exception_handler_logic(
    exc: RateNotFoundException,
) -> Dict[str, Any]:
    response_content = produce_response_content(exc)
    response_content["detail"] = exc.message
    response_content["title"] = "Rate not found"
    response_content["message"] = "Rate not found for the provided criteria"
    return response_content


def provider_not_found_exception_handler_logic(
    exc: RateNotFoundException,
) -> Dict[str, Any]:
    response_content = produce_response_content(exc)
    response_content["detail"] = exc.message
    response_content["title"] = "Provider not found"
    response_content["message"] = "Provider not found for the provided criteria"
    return response_content


async def rate_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle RateNotFoundException and return appropriate 500 response."""
    if isinstance(exc, RateNotFoundException):
        return JSONResponse(
            content=rate_not_found_exception_handler_logic(exc), status_code=500
        )
    else:
        return JSONResponse(content=produce_response_content(exc), status_code=500)


def benefits_not_found_exception_handler_logic(
    exc: BenefitsNotFoundException,
) -> Dict[str, Any]:
    response_content = produce_response_content(exc)
    # Extract status from message if it contains "Status X:"
    message = exc.message
    status = 500  # Default status

    if message.startswith("Status "):
        try:
            # Extract status code from "Status 400: message" format
            status_part = message.split(":")[0]
            status = int(status_part.replace("Status ", ""))
            # Clean up message to remove status prefix
            message = ":".join(message.split(":")[1:]).strip()
        except (ValueError, IndexError):
            # If parsing fails, keep original message and status
            pass

    response_content["detail"] = message
    response_content["title"] = "Benefits not found"
    response_content["message"] = "Benefits not found for the provided request"
    response_content["status"] = status
    return response_content


async def benefits_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle BenefitsNotFoundException and return appropriate response with status from message."""
    if isinstance(exc, BenefitsNotFoundException):
        return JSONResponse(
            content=benefits_not_found_exception_handler_logic(exc), status_code=500
        )
    else:
        return JSONResponse(content=produce_response_content(exc), status_code=500)


async def benefits_member_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle BenefitsMemberNotFoundException and return appropriate response with status from message."""
    if isinstance(exc, BenefitsMemberNotFoundException):
        return JSONResponse(
            content=benefits_member_not_found_exception_handler_logic(exc),
            status_code=500,
        )
    else:
        return JSONResponse(content=produce_response_content(exc), status_code=500)


def benefits_member_not_found_exception_handler_logic(
    exc: BenefitsMemberNotFoundException,
) -> Dict[str, Any]:
    response_content = produce_response_content(exc)
    # Extract status from message if it contains "Status X:"
    message = exc.message
    status = 500  # Default status

    if message.startswith("Status "):
        try:
            # Extract status code from "Status 400: message" format
            status_part = message.split(":")[0]
            status = int(status_part.replace("Status ", ""))
            # Clean up message to remove status prefix
            message = ":".join(message.split(":")[1:]).strip()
        except (ValueError, IndexError):
            # If parsing fails, keep original message and status
            pass

    response_content["detail"] = message
    response_content["title"] = "Member not found by benefits api"
    response_content["message"] = "Member not found by benefits api"
    response_content["status"] = status
    return response_content


def benefits_not_matching_exception_handler_logic(
    exc: BenefitsNotMatchingException,
) -> Dict[str, Any]:
    response_content = produce_response_content(exc)
    response_content["detail"] = exc.message
    response_content["title"] = "Benefits not matching"
    response_content["message"] = "No matching selected benefits"
    response_content["status"] = 500
    return response_content


async def benefits_not_matching_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle BenefitsNotMatchingException and return appropriate response with status from message."""
    if isinstance(exc, BenefitsNotMatchingException):
        return JSONResponse(
            content=benefits_not_matching_exception_handler_logic(exc), status_code=500
        )
    else:
        return JSONResponse(content=produce_response_content(exc), status_code=500)


async def accumulator_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle AccumulatorNotFoundException and return appropriate response with status from message."""
    response_content = produce_response_content(exc)
    if isinstance(exc, AccumulatorNotFoundException):
        # Extract status from message if it contains "Status X:"
        message = exc.message
        status = 500  # Default status

        if message.startswith("Status "):
            try:
                # Extract status code from "Status 400: message" format
                status_part = message.split(":")[0]
                status = int(status_part.replace("Status ", ""))
                # Clean up message to remove status prefix
                message = ":".join(message.split(":")[1:]).strip()
            except (ValueError, IndexError):
                # If parsing fails, keep original message and status
                pass

        response_content["detail"] = message
        response_content["title"] = "Accumulator not found"
        response_content["message"] = "Accumulator not found for the provided request"
        response_content["status"] = status

        return JSONResponse(content=response_content, status_code=500)

    return JSONResponse(content=response_content, status_code=500)


async def accumulator_member_not_found_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle AccumulatorNotFoundException and return appropriate response with status from message."""
    response_content = produce_response_content(exc)
    if isinstance(exc, AccumulatorMemberNotFoundException):
        # Extract status from message if it contains "Status X:"
        message = exc.message
        status = 500  # Default status

        if message.startswith("Status "):
            try:
                # Extract status code from "Status 400: message" format
                status_part = message.split(":")[0]
                status = int(status_part.replace("Status ", ""))
                # Clean up message to remove status prefix
                message = ":".join(message.split(":")[1:]).strip()
            except (ValueError, IndexError):
                # If parsing fails, keep original message and status
                pass

        response_content["detail"] = message
        response_content["title"] = "Member not found by accumulator api"
        response_content["message"] = "Member not found by accumulator api"
        response_content["status"] = status

        return JSONResponse(content=response_content, status_code=500)

    return JSONResponse(content=response_content, status_code=500)


def insurance_context_error_exception_handler_logic(
    exc: InsuranceContextException,
) -> Dict[str, Any]:
    response_content = produce_response_content(exc)
    response_content["detail"] = exc.message
    if exc.error_code is not None:
        response_content["detail"] += f" with error code {exc.error_code}"
    if exc.error_message is not None:
        response_content["detail"] += f" and error message {exc.error_message}"
    response_content["title"] = "Insurance context error"
    response_content["message"] = "Insurance context error for the provided request"
    return response_content


async def insurance_context_error_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle InsuranceContextException and return appropriate 500 response."""
    if isinstance(exc, InsuranceContextException):
        return JSONResponse(
            content=insurance_context_error_exception_handler_logic(exc),
            status_code=500,
        )
    else:
        return JSONResponse(content=produce_response_content(exc), status_code=500)


async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Handle generic exceptions and return appropriate 500 response."""
    return JSONResponse(content=produce_response_content(exc), status_code=500)


def include_exceptions(app: FastAPI):
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(RateNotFoundException, rate_not_found_exception_handler)
    app.add_exception_handler(
        BenefitsNotFoundException, benefits_not_found_exception_handler
    )
    app.add_exception_handler(
        BenefitsMemberNotFoundException, benefits_member_not_found_exception_handler
    )
    app.add_exception_handler(
        BenefitsNotMatchingException, benefits_not_matching_exception_handler
    )
    app.add_exception_handler(
        AccumulatorNotFoundException, accumulator_not_found_exception_handler
    )
    app.add_exception_handler(
        AccumulatorMemberNotFoundException,
        accumulator_member_not_found_exception_handler,
    )
    app.add_exception_handler(
        InsuranceContextException, insurance_context_error_exception_handler
    )
    app.add_exception_handler(Exception, generic_exception_handler)
    return app
