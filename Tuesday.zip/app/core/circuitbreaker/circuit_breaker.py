"""
Circuit Breaker Implementation

A clean, optimized circuit breaker with annotation support and generic fallback mechanism.
"""

import asyncio
import functools
import time
from typing import Any, Callable, Dict, Optional
from circuitbreaker import CircuitBreaker as BaseCircuitBreaker
from app.core.logger import logger
from app.exception.exceptions import CircuitBreakerOpenException


class CircuitBreaker(BaseCircuitBreaker):
    """Circuit breaker with optimized defaults."""

    def __init__(self, name: str, fallback_function: Optional[Callable] = None):
        super().__init__(
            failure_threshold=3,
            recovery_timeout=60,
            expected_exception=(Exception,),
            name=name,
            fallback_function=fallback_function,
        )
        logger.info(f"Created CircuitBreaker: {name}")


def circuit_breaker(api_name: str, fallback_function: Optional[Callable] = None):
    """
    Circuit breaker decorator.

    Args:
        api_name: Name of the API/service
        fallback_function: Optional fallback function (default: fallback)

    Usage:
        @circuit_breaker("user_service")
        async def get_user(user_id: str):
            # Your API call here
            pass
    """

    def decorator(func: Callable) -> Callable:
        # Create circuit breaker instance
        cb = CircuitBreaker(
            name=api_name,
            fallback_function=fallback_function or _create_fallback(func),
        )

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Check if circuit is open and call fallback directly
            if cb.state == "open":
                # Check if recovery timeout has passed
                import time
                if cb.open_until and time.time() >= cb.open_until.timestamp():
                    # Circuit breaker should be in half-open state, try the call
                    return await cb.call_async(func, *args, **kwargs)
                else:
                    # Still in open state, use fallback
                    if cb.fallback_function:
                        return cb.fallback_function(*args, **kwargs)
                    else:
                        raise CircuitBreakerOpenException(
                            message="Circuit breaker is open",
                            service_name=cb.name,
                            circuit_breaker_state="open"
                        )
            return await cb.call_async(func, *args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            # Check if circuit is open and call fallback directly
            if cb.state == "open":
                # Check if recovery timeout has passed
                import time
                if cb.open_until and time.time() >= cb.open_until.timestamp():
                    # Circuit breaker should be in half-open state, try the call
                    return cb.call(func, *args, **kwargs)
                else:
                    # Still in open state, use fallback
                    if cb.fallback_function:
                        return cb.fallback_function(*args, **kwargs)
                    else:
                        raise CircuitBreakerOpenException(
                            message="Circuit breaker is open",
                            service_name=cb.name,
                            circuit_breaker_state="open"
                        )
            return cb.call(func, *args, **kwargs)

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


def _create_fallback(original_func: Callable) -> Callable:
    """Create a fallback function that raises a circuit breaker exception."""

    def fallback(*args, **kwargs):
        """Fallback that raises an exception when circuit breaker is open."""
        # Determine service type based on function name
        service_type = _determine_service_type(original_func.__name__)
        
        logger.warning(
            f"Circuit breaker fallback triggered for {service_type} service: {original_func.__name__}"
        )

        # Raise a circuit breaker exception with service type information
        raise CircuitBreakerOpenException(
            message=f"{service_type} service temporarily unavailable due to circuit breaker being open",
            service_name=f"{service_type}_{original_func.__name__}",
            circuit_breaker_state="open",
            service_type=service_type
        )

    return fallback


def _determine_service_type(function_name: str) -> str:
    """Determine the service type based on function name."""
    function_name_lower = function_name.lower()
    
    if "benefit" in function_name_lower:
        return "Benefit"
    elif "accumulator" in function_name_lower or "accum" in function_name_lower:
        return "Accumulator"
    elif "rate" in function_name_lower:
        return "Rate"
    elif "token" in function_name_lower:
        return "Token"
    else:
        return "Service"


# Global registry for monitoring
CIRCUIT_BREAKER_REGISTRY: Dict[str, CircuitBreaker] = {}


def register_circuit_breaker(cb: CircuitBreaker) -> None:
    """Register circuit breaker in global registry."""
    if cb.name:
        CIRCUIT_BREAKER_REGISTRY[cb.name] = cb
        logger.info(f"Registered circuit breaker: {cb.name}")

# TODO: Add a function to get the health of a specific circuit breaker
def get_circuit_breaker_health() -> Dict[str, Any]:
    """Get health status of all circuit breakers."""
    all_cbs = list(CIRCUIT_BREAKER_REGISTRY.values())
    total_cbs = len(all_cbs)
    healthy_cbs = sum(
        1 for cb in all_cbs if cb.state == "closed"
    )

    return {
        "total_circuit_breakers": total_cbs,
        "healthy_circuit_breakers": healthy_cbs,
        "unhealthy_circuit_breakers": total_cbs - healthy_cbs,
        "health_percentage": (healthy_cbs / total_cbs * 100) if total_cbs > 0 else 100,
        "circuit_breakers": {
            name: {
                "name": cb.name,
                            "state": cb.state,
            "failure_count": cb.failure_count,
            "failure_threshold": cb._failure_threshold,
            "recovery_timeout": cb._recovery_timeout,
            "is_healthy": cb.state == "closed",
            }
            for name, cb in CIRCUIT_BREAKER_REGISTRY.items()
        },
    }


# Auto-register circuit breakers
_original_init = CircuitBreaker.__init__


def _patched_init(self, name: str, fallback_function: Optional[Callable] = None):
    _original_init(self, name, fallback_function)
    register_circuit_breaker(self)


CircuitBreaker.__init__ = _patched_init
