from typing import Optional, Dict, Any
from datetime import datetime, timedelta


class SessionManager:
    """Manages session tokens and their lifecycle."""

    _instance = None
    _token: Optional[str | Dict[str, str]] = None
    _token_expiry: Optional[datetime] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SessionManager, cls).__new__(cls)
        return cls._instance

    @classmethod
    def set_token(cls, token: str, expires_in: int = 3600) -> None:
        """Set the session token and its expiry time."""
        cls._token = token
        cls._token_expiry = datetime.now() + timedelta(seconds=expires_in)

    @classmethod
    def get_token(cls) -> Optional[str | Dict[str, str]]:
        """Get the current token if it's still valid."""
        if cls._token and cls._token_expiry and datetime.now() < cls._token_expiry:
            return cls._token
        return None

    @classmethod
    def clear_token(cls) -> None:
        """Clear the current token."""
        cls._token = None
        cls._token_expiry = None
