from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
from app.core.logger import logger
from app.repository.impl.cost_estimator_repository_impl import (
    CostEstimatorRepositoryImpl,
)
from app.services.impl.benefit_accumulator_matcher_service_impl import (
    BenefitAccumulatorMatcherServiceImpl,
)
from app.services.impl.benefit_service_impl import BenefitServiceImpl
from app.services.impl.accumulator_service_impl import AccumulatorServiceImpl
from app.services.impl.calculation_service_impl import CalculationServiceImpl


class ServiceFactory:
    _instance = None
    _cost_estimation_service = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ServiceFactory, cls).__new__(cls)
        return cls._instance

    def cost_estimation_service(
        self,
    ) -> CostEstimationServiceImpl:
        """Get or create the global CostEstimationServiceImpl instance."""
        if self._cost_estimation_service is None:
            logger.info("Creating global CostEstimationServiceImpl instance")
            self._cost_estimation_service = CostEstimationServiceImpl(
                repository=CostEstimatorRepositoryImpl(),
                matcher_service=BenefitAccumulatorMatcherServiceImpl(),
                benefit_service=BenefitServiceImpl(),
                accumulator_service=AccumulatorServiceImpl(),
                calculation_service=CalculationServiceImpl(),
            )
        else:
            logger.info("CostEstimationServiceImpl instance already exists")
        return self._cost_estimation_service
