from abc import ABC, abstractmethod
from typing import List
from app.core.base import InsuranceContext, Benefit


class CalculationServiceInterface(ABC):
    """Interface for calculation service that processes insurance benefits"""

    @abstractmethod
    def find_highest_member_pay(
        self, service_amount: float, benefits: List[Benefit]
    ) -> InsuranceContext:
        """
        Find the insurance context with the highest member pay from a list of benefits.

        Args:
            service_amount: The service amount to calculate for
            benefits: List of benefits to process

        Returns:
            InsuranceContext: The context with the highest member_pays value
        """
        pass
