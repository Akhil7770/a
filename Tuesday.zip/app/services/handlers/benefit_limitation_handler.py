from app.core.base import Handler, InsuranceContext


class BenefitLimitationHandler(Handler):
    """Handle the benefits limitation"""

    # TODO: Do we need this handler
    def set_deductible_cost_share_co_handler(self, handler):
        self._deductible_cost_share_co_handler = handler
        return handler

    def set_oopmax_handler(self, handler):
        self._oopmax_handler = handler
        return handler

    def process(self, context: InsuranceContext) -> InsuranceContext:
        if "limit" not in context.accum_code:
            context.trace_decision("Process", "Context has no benefit limitation", True)
            return context

        # Now check if the limit has been reached
        if (
            context.accum_code
            and "limit" in [code.lower() for code in context.accum_code]
            and (context.limit_calculated is None or context.limit_calculated == 0)
        ):
            context.trace_decision(
                "Process",
                "The benefit code is 'limit' and the calculated limit is 0, applying benefit service is not covered as benefit limit has reached",
                True,
            )
            context.calculation_complete = True
            return context
            # return self._apply_limitation(context)

        # Handle the scenario when the limit type is a dollar amount
        if context.limit_type and context.limit_type.lower() == "dollar":
            if context.limit_calculated is not None and context.limit_calculated > 0:
                self._oopmax_handler.handle(context)
                if context.service_amount > context.limit_calculated:
                    return self._apply_partial_limit(context)
                else:
                    return self._apply_within_limit(context)

        # Handle the scenario when the limit type is a quantity
        elif context.limit_type and context.limit_type.lower() == "counter":
            if context.limit_calculated is not None and context.limit_calculated > 0:
                self._oopmax_handler.handle(context)
                return self._apply_limitation(context)
            else:
                context.trace_decision(
                    "Process",
                    "The benefit code is 'limit' and the calculated limit is 0, applying benefit service is not covered as benefit limit has reached",
                    True,
                )
                context.calculation_complete = True
                return context

        # We only know of 2 limit types. We have an unknown limit type, throw an exception
        raise Exception(
            f"Uknown benefit limit type. Unable to proceed. Limit type passed: {context.limit_type}"
        )

    def _apply_limitation(self, context: InsuranceContext) -> InsuranceContext:
        """Apply logic when benefit limit has been reached"""

        if context.limit_calculated is not None:
            context.limit_calculated = context.limit_calculated - 1
        context.calculation_complete = True

        context.trace("_apply_limitation", "Logic applied")

        return context

    def _apply_partial_limit(self, context: InsuranceContext) -> InsuranceContext:
        """Apply logic when service exceeds the remaining benefit limit"""

        if context.limit_calculated is not None:
            context.member_pays += context.service_amount - context.limit_calculated
            context.limit_calculated = 0.0
        # else:
        #     context.insurance_pays = 0.0
        context.calculation_complete = True

        context.trace("_apply_partial_limit", "Logic applied")

        return context

    def _apply_within_limit(self, context: InsuranceContext) -> InsuranceContext:
        """Service is within the benefit limits"""

        if context.limit_calculated is not None:
            # context.limit_calculated = context.limit_calculated - context.insurance_pays
            context.limit_calculated -= context.service_amount
        context.calculation_complete = True

        context.trace("_apply_within_limit", "Logic applied")

        return context
