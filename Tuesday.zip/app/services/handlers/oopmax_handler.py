from app.core.base import Handler, InsuranceContext


class OOPMaxHandler(Handler):
    """Check if the out of pocket max are met or if an out of pocket max exists"""

    def set_deductible_handler(self, handler):
        self._deductible_handler = handler
        return handler

    def set_oopmax_copay_handler(self, handler):
        self._oopmax_copay_handler = handler
        return handler

    def process(self, context: InsuranceContext) -> InsuranceContext:
        # Need to check if we have an OOPMax
        if "oopmax" not in context.accum_code:
            context.trace_decision("Process", "A OOPMax was not provided", False)
            return self._deductible_handler.handle(context)

        if (
            "oopmax_family" in context.accum_level
            and context.oopmax_family_calculated is not None
            and context.oopmax_family_calculated == 0
        ):
            return self._oopmax_copay_handler.handle(context)

        if (
            "oopmax_individual" in context.accum_level
            and context.oopmax_individual_calculated is not None
            and context.oopmax_individual_calculated == 0
        ):
            return self._oopmax_copay_handler.handle(context)

        return self._deductible_handler.handle(context)
