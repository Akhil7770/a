import os.path

"""SQL query configurations for the cost estimator service."""


def load_query(query_name: str) -> str:
    return open(
        os.path.join(os.path.dirname(__file__), "queries", f"{query_name}.sql")
    ).read()


RATE_QUERIES = {
    "get_out_of_network_rate": load_query("get_out_of_network_rate"),
    "get_claim_based_rate": load_query("get_claim_based_rate"),
    "get_provider_info": load_query("get_provider_info"),
    "get_standard_rate": load_query("get_standard_rate"),
    "get_non_standard_rate": load_query("get_non_standard_rate"),
    "get_default_rate": load_query("get_default_rate"),
    "get_payment_method_hierarchy": load_query("get_payment_method_hierarchy"),
    "get_non_standard_rate_with_specialty_cd": load_query("get_non_standard_rate_with_specialty_cd"),
    "get_non_standard_rate_with_provider_type_cd": load_query("get_non_standard_rate_with_provider_type_cd"),
    "get_default_rate_with_specialty_cd": load_query("get_default_rate_with_specialty_cd"),
    "get_default_rate_with_provider_type_cd": load_query("get_default_rate_with_provider_type_cd"),
}
