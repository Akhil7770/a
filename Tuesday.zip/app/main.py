import asyncio
from fastapi import FastAPI
from app.api.router import router
from app.exception.exception_handler import include_exceptions
from contextlib import asynccontextmanager
from app.services.token_service import TokenService
from app.core.logger import logger
from app.core.session_manager import SessionManager
from app.core.service_factory import ServiceFactory

app = FastAPI(
    title="Cost Estimator API",
    description="Handles input validation.",
    version="1.0.0",
)

app = include_exceptions(app)
app.include_router(router)

service_factory = ServiceFactory()
cost_estimation_service = service_factory.cost_estimation_service()


async def refresh_cache_every_24_hours():
    while True:
        logger.info("Refreshing cache")
        await cost_estimation_service.load_payment_method_hierarchy()
        await cost_estimation_service.load_pcp_specialty_codes()
        await asyncio.sleep(86400)  # 24 hours in seconds


async def refresh_token_every_hour():
    while True:
        await get_token()
        await asyncio.sleep(3540)  # 59 minutes in seconds


# FastAPI lifespan event
@asynccontextmanager
async def lifespan(app: FastAPI):
    asyncio.create_task(refresh_token_every_hour())  # Start hourly token refresh
    asyncio.create_task(refresh_cache_every_24_hours())
    yield  # Wait for the app to shut down


async def get_token():
    logger.info("Getting new token")
    token_service = TokenService()
    token_data = await token_service.get_new_token()
    expires_in = token_data.get("expires_in", 3600)  # Default to 1 hour if not provided
    SessionManager.set_token(token_data)
    # SessionManager.set_token(token_data["access_token"], expires_in)
    logger.info("Token acquired and stored in SessionManager")


app.router.lifespan_context = lifespan
