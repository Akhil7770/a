"""
API Mock Testing for Deductible Scenarios

This module contains comprehensive API tests for different deductible scenarios
using the mock data from tests/mock-data/mock-api-test-data/deductible/
"""

import json
import os
from pathlib import Path
from typing import Dict, Any
from unittest.mock import patch, AsyncMock, MagicMock
import pytest
from fastapi.testclient import TestClient
from httpx import AsyncClient

from app.main import app
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.schemas.cost_estimator_response import CostEstimatorResponse


class TestDeductibleMockAPI:
    """Test class for deductible-related API mock testing."""
    
    @pytest.fixture(autouse=True)
    def setup_method(self):
        """Setup method to initialize test data paths."""
        self.base_path = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "deductible" / "no_deductible_applies"
        self.test_data_files = {
            "cost_response": "cost_response.json"
        }
    
    def load_test_data(self, scenario: str) -> Dict[str, Any]:
        """Load test data from JSON file for given scenario."""
        file_path = self.base_path / self.test_data_files[scenario]
        with open(file_path, 'r') as f:
            return json.load(f)
    
    @pytest.fixture
    def mock_external_services(self):
        """Mock external services and dependencies."""
        with patch('app.services.impl.cost_estimation_service_impl.CostEstimationServiceImpl.estimate_cost') as mock_estimate, \
             patch('app.services.token_service.TokenService.get_new_token') as mock_token, \
             patch('app.database.spanner_client.SpannerClient') as mock_spanner:
            
            # Mock token service
            mock_token.return_value = {
                "access_token": "mock_token_123",
                "expires_in": 3600,
                "token_type": "Bearer"
            }
            
            # Load the expected response from the cost_response.json file
            cost_response_path = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "deductible" / "no_deductible_applies" / "cost_response.json"
            with open(cost_response_path, 'r') as f:
                expected_response_data = json.load(f)
            
            # Create response object from the loaded data
            from app.schemas.cost_estimator_response import CostEstimatorResponse
            
            # Convert the JSON response to a CostEstimatorResponse object
            mock_response = CostEstimatorResponse.model_validate(expected_response_data)
            mock_estimate.return_value = mock_response
            
            yield {
                'estimate': mock_estimate,
                'token': mock_token,
                'spanner': mock_spanner
            }
    
    @pytest.mark.api
    @pytest.mark.asyncio
    async def test_no_deductible_applies_scenario(self, client: TestClient, mock_external_services):
        """Test scenario where deductible doesn't apply using cost_response.json data."""
        # Load expected response data
        expected_response = self.load_test_data("cost_response")
        
        # Create minimal request data based on response structure
        service_info = expected_response["costEstimateResponse"]["service"]
        provider_info = expected_response["costEstimateResponse"]["costEstimateResponseInfo"][0]["providerInfo"]
        
        test_data = {
            "membershipId": "5~265646854+10+725+20250101+799047+BA+42",
            "zipCode": "",
            "benefitProductType": "Medical",
            "languageCode": "11",
            "service": {
                "code": service_info["code"],
                "type": service_info["type"],
                "description": service_info.get("description", ""),
                "supportingService": service_info.get("supportingService", {"code": "", "type": ""}),
                "modifier": service_info.get("modifier", {"modifierCode": ""}),
                "diagnosisCode": service_info.get("diagnosisCode", ""),
                "placeOfService": service_info["placeOfService"]
            },
            "providerInfo": [
                {
                    "serviceLocation": provider_info["serviceLocation"],
                    "providerType": provider_info["providerType"],
                    "speciality": provider_info.get("speciality", {"code": ""}),
                    "taxIdentificationNumber": provider_info.get("taxIdentificationNumber", ""),
                    "taxIdQualifier": provider_info.get("taxIdQualifier", ""),
                    "providerNetworks": provider_info.get("providerNetworks", {"networkID": ""}),
                    "providerIdentificationNumber": provider_info.get("providerIdentificationNumber", ""),
                    "nationalProviderId": provider_info.get("nationalProviderId", ""),
                    "providerNetworkParticipation": provider_info.get("providerNetworkParticipation", {"providerTier": ""})
                }
            ]
        }
        
        # Prepare headers
        headers = {
            "Content-Type": "application/json",
            "x-global-transaction-id": "test-transaction-no-deductible-001",
            "x-clientrefid": "test-client-no-deductible-001"
        }
        
        # Make API call
        response = client.post(
            "/costestimator/v1/rate",
            json=test_data,
            headers=headers
        )
        
        # Assertions
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        response_data = response.json()
        assert "costEstimateResponse" in response_data
        cost_estimate_response = response_data["costEstimateResponse"]
        assert "service" in cost_estimate_response
        assert "costEstimateResponseInfo" in cost_estimate_response
        assert len(cost_estimate_response["costEstimateResponseInfo"]) > 0
        
        # Verify service was called with correct data
        mock_external_services['estimate'].assert_called_once()
        call_args = mock_external_services['estimate'].call_args
        request_obj = call_args[0][0]
        assert request_obj.membershipId == test_data["membershipId"]
        assert request_obj.service.code == "21137"  # CPT4 code from test data
        
        # Validate specific response structure matches expected
        response_info = cost_estimate_response["costEstimateResponseInfo"][0]
        expected_info = expected_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        
        # Validate coverage
        assert response_info["coverage"]["isServiceCovered"] == expected_info["coverage"]["isServiceCovered"]
        assert response_info["coverage"]["costShareCoinsurance"] == expected_info["coverage"]["costShareCoinsurance"]
        
        # Validate cost structure
        assert response_info["cost"]["inNetworkCosts"] == expected_info["cost"]["inNetworkCosts"]
        assert response_info["cost"]["inNetworkCostsType"] == expected_info["cost"]["inNetworkCostsType"]
        
        # Validate accumulators are present
        assert "accumulators" in response_info
        accumulators = response_info["accumulators"]
        assert len(accumulators) == 4  # Should have 2 Deductible + 2 OOP Max accumulators
        
        # Validate accumulator types
        accumulator_codes = [acc["accumulator"]["code"] for acc in accumulators]
        assert "Deductible" in accumulator_codes
        assert "OOP Max" in accumulator_codes
    
    
    
    @pytest.mark.api
    @pytest.mark.asyncio
    @pytest.mark.parametrize("scenario,expected_code", [
        ("cost_response", "21137")
    ])
    async def test_all_deductible_scenarios_parametrized(
        self, 
        client: TestClient, 
        mock_external_services, 
        scenario: str, 
        expected_code: str
    ):
        """Parametrized test for cost estimation scenario using cost_response.json."""
        # Load expected response data
        expected_response = self.load_test_data(scenario)
        
        # Create minimal request data based on response structure
        service_info = expected_response["costEstimateResponse"]["service"]
        provider_info = expected_response["costEstimateResponse"]["costEstimateResponseInfo"][0]["providerInfo"]
        
        test_data = {
            "membershipId": "5~265646854+10+725+20250101+799047+BA+42",
            "zipCode": "",
            "benefitProductType": "Medical",
            "languageCode": "11",
            "service": {
                "code": service_info["code"],
                "type": service_info["type"],
                "description": service_info.get("description", ""),
                "supportingService": service_info.get("supportingService", {"code": "", "type": ""}),
                "modifier": service_info.get("modifier", {"modifierCode": ""}),
                "diagnosisCode": service_info.get("diagnosisCode", ""),
                "placeOfService": service_info["placeOfService"]
            },
            "providerInfo": [
                {
                    "serviceLocation": provider_info["serviceLocation"],
                    "providerType": provider_info["providerType"],
                    "speciality": provider_info.get("speciality", {"code": ""}),
                    "taxIdentificationNumber": provider_info.get("taxIdentificationNumber", ""),
                    "taxIdQualifier": provider_info.get("taxIdQualifier", ""),
                    "providerNetworks": provider_info.get("providerNetworks", {"networkID": ""}),
                    "providerIdentificationNumber": provider_info.get("providerIdentificationNumber", ""),
                    "nationalProviderId": provider_info.get("nationalProviderId", ""),
                    "providerNetworkParticipation": provider_info.get("providerNetworkParticipation", {"providerTier": ""})
                }
            ]
        }
        
        # Prepare headers
        headers = {
            "Content-Type": "application/json",
            "x-global-transaction-id": f"test-transaction-{scenario}-param",
            "x-clientrefid": f"test-client-{scenario}-param"
        }
        
        # Make API call
        response = client.post(
            "/costestimator/v1/rate",
            json=test_data,
            headers=headers
        )
        
        # Assertions
        assert response.status_code == 200
        response_data = response.json()
        assert "costEstimateResponse" in response_data
        cost_estimate_response = response_data["costEstimateResponse"]
        assert "service" in cost_estimate_response
        assert "costEstimateResponseInfo" in cost_estimate_response
        
        # Verify service code matches expected
        mock_external_services['estimate'].assert_called()
        call_args = mock_external_services['estimate'].call_args
        request_obj = call_args[0][0]
        assert request_obj.service.code == expected_code
    
    @pytest.mark.api
    @pytest.mark.asyncio
    async def test_invalid_request_validation(self, client: TestClient):
        """Test API validation with invalid request data."""
        # Invalid request missing required fields
        invalid_data = {
            "membershipId": "",  # Empty membership ID
            "zipCode": "12345"
            # Missing other required fields
        }
        
        headers = {
            "Content-Type": "application/json",
            "x-global-transaction-id": "test-transaction-invalid-001"
        }
        
        response = client.post(
            "/costestimator/v1/rate",
            json=invalid_data,
            headers=headers
        )
        
        # Should return validation error (400 or 422 are both acceptable)
        assert response.status_code in [400, 422]
        error_data = response.json()
        assert "detail" in error_data
    
    @pytest.mark.api
    @pytest.mark.asyncio
    async def test_missing_headers_handling(self, client: TestClient, mock_external_services):
        """Test API behavior with missing optional headers."""
        # Create test data from cost_response
        expected_response = self.load_test_data("cost_response")
        service_info = expected_response["costEstimateResponse"]["service"]
        provider_info = expected_response["costEstimateResponse"]["costEstimateResponseInfo"][0]["providerInfo"]
        
        test_data = {
            "membershipId": "5~265646854+10+725+20250101+799047+BA+42",
            "zipCode": "",
            "benefitProductType": "Medical",
            "languageCode": "11",
            "service": {
                "code": service_info["code"],
                "type": service_info["type"],
                "description": service_info.get("description", ""),
                "supportingService": service_info.get("supportingService", {"code": "", "type": ""}),
                "modifier": service_info.get("modifier", {"modifierCode": ""}),
                "diagnosisCode": service_info.get("diagnosisCode", ""),
                "placeOfService": service_info["placeOfService"]
            },
            "providerInfo": [
                {
                    "serviceLocation": provider_info["serviceLocation"],
                    "providerType": provider_info["providerType"],
                    "speciality": provider_info.get("speciality", {"code": ""}),
                    "taxIdentificationNumber": provider_info.get("taxIdentificationNumber", ""),
                    "taxIdQualifier": provider_info.get("taxIdQualifier", ""),
                    "providerNetworks": provider_info.get("providerNetworks", {"networkID": ""}),
                    "providerIdentificationNumber": provider_info.get("providerIdentificationNumber", ""),
                    "nationalProviderId": provider_info.get("nationalProviderId", ""),
                    "providerNetworkParticipation": provider_info.get("providerNetworkParticipation", {"providerTier": ""})
                }
            ]
        }
        
        # Minimal headers (only required ones)
        headers = {
            "Content-Type": "application/json"
        }
        
        # Make API call
        response = client.post(
            "/costestimator/v1/rate",
            json=test_data,
            headers=headers
        )
        
        # Should still work with minimal headers
        assert response.status_code == 200
        response_data = response.json()
        assert "costEstimateResponse" in response_data
        cost_estimate_response = response_data["costEstimateResponse"]
        assert "service" in cost_estimate_response
        assert "costEstimateResponseInfo" in cost_estimate_response
    
    @pytest.mark.api
    @pytest.mark.asyncio
    async def test_service_error_handling(self, client: TestClient):
        """Test API error handling when service throws exception."""
        with patch('app.services.impl.cost_estimation_service_impl.CostEstimationServiceImpl.estimate_cost') as mock_estimate:
            # Mock service to raise exception
            mock_estimate.side_effect = Exception("Service unavailable")
            
            # Create minimal request data from cost_response
            expected_response = self.load_test_data("cost_response")
            service_info = expected_response["costEstimateResponse"]["service"]
            provider_info = expected_response["costEstimateResponse"]["costEstimateResponseInfo"][0]["providerInfo"]
            
            test_data = {
                "membershipId": "5~265646854+10+725+20250101+799047+BA+42",
                "zipCode": "",
                "benefitProductType": "Medical",
                "languageCode": "11",
                "service": {
                    "code": service_info["code"],
                    "type": service_info["type"],
                    "description": service_info.get("description", ""),
                    "supportingService": service_info.get("supportingService", {"code": "", "type": ""}),
                    "modifier": service_info.get("modifier", {"modifierCode": ""}),
                    "diagnosisCode": service_info.get("diagnosisCode", ""),
                    "placeOfService": service_info["placeOfService"]
                },
                "providerInfo": [
                    {
                        "serviceLocation": provider_info["serviceLocation"],
                        "providerType": provider_info["providerType"],
                        "speciality": provider_info.get("speciality", {"code": ""}),
                        "taxIdentificationNumber": provider_info.get("taxIdentificationNumber", ""),
                        "taxIdQualifier": provider_info.get("taxIdQualifier", ""),
                        "providerNetworks": provider_info.get("providerNetworks", {"networkID": ""}),
                        "providerIdentificationNumber": provider_info.get("providerIdentificationNumber", ""),
                        "nationalProviderId": provider_info.get("nationalProviderId", ""),
                        "providerNetworkParticipation": provider_info.get("providerNetworkParticipation", {"providerTier": ""})
                    }
                ]
            }
            headers = {
                "Content-Type": "application/json",
                "x-global-transaction-id": "test-transaction-error-001"
            }
            
            # Since the application doesn't have proper error handling middleware,
            # the exception will bubble up as expected in this test scenario
            try:
                response = client.post(
                    "/costestimator/v1/rate",
                    json=test_data,
                    headers=headers
                )
                # If we get here, check for proper error codes
                assert response.status_code in [500, 422, 400]
            except Exception as e:
                # If exception bubbles up, that's also valid behavior for unhandled service errors
                assert "Service unavailable" in str(e)


@pytest.mark.api
class TestDeductibleMockAPIUtils:
    """Utility tests for deductible mock API testing."""
    
    @pytest.mark.asyncio
    async def test_mock_data_integrity(self):
        """Test that cost_response.json file is valid and loadable."""
        base_path = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "deductible" / "no_deductible_applies"
        test_files = [
            "cost_response.json"
        ]
        
        for file_name in test_files:
            file_path = base_path / file_name
            assert file_path.exists(), f"Test data file {file_name} not found"
            
            # Load and validate JSON structure
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # Validate cost_response.json structure
            assert "costEstimateResponse" in data, f"costEstimateResponse missing in {file_name}"
            cost_response = data["costEstimateResponse"]
            
            # Validate response sections
            assert "service" in cost_response, f"service missing in response {file_name}"
            assert "costEstimateResponseInfo" in cost_response, f"costEstimateResponseInfo missing in response {file_name}"
            
            response_info = cost_response["costEstimateResponseInfo"]
            assert isinstance(response_info, list), f"costEstimateResponseInfo should be list in {file_name}"
            assert len(response_info) > 0, f"costEstimateResponseInfo should not be empty in {file_name}"
            
            # Validate first response info structure
            first_info = response_info[0]
            required_sections = ["providerInfo", "coverage", "cost", "healthClaimLine", "accumulators"]
            for section in required_sections:
                assert section in first_info, f"Required section {section} missing in {file_name}"
    
    def test_cost_response_data_quality(self):
        """Test that cost_response.json data meets quality standards."""
        base_path = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "deductible" / "no_deductible_applies"
        
        # Load response data
        with open(base_path / "cost_response.json", 'r') as f:
            response_data = json.load(f)
        
        # Verify response structure contains expected elements
        response_info = response_data["costEstimateResponse"]["costEstimateResponseInfo"][0]
        required_sections = ["coverage", "cost", "healthClaimLine", "accumulators"]
        for section in required_sections:
            assert section in response_info, f"Response should contain {section} section"
        
        # Verify service code is valid
        service_code = response_data["costEstimateResponse"]["service"]["code"]
        assert service_code == "21137", f"Expected service code 21137, got {service_code}"
        
        # Verify provider info has required fields
        provider_info = response_info["providerInfo"]
        assert "serviceLocation" in provider_info, "Provider info should have serviceLocation"
        assert "providerType" in provider_info, "Provider info should have providerType"
        assert "providerNetworks" in provider_info, "Provider info should have providerNetworks"
        
        # Verify accumulators structure
        accumulators = response_info["accumulators"]
        assert len(accumulators) == 4, f"Expected 4 accumulators, got {len(accumulators)}"
        
        # Verify we have both Deductible and OOP Max accumulators
        accumulator_codes = [acc["accumulator"]["code"] for acc in accumulators]
        assert "Deductible" in accumulator_codes, "Should have Deductible accumulators"
        assert "OOP Max" in accumulator_codes, "Should have OOP Max accumulators"
