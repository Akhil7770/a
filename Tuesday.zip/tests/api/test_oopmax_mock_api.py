"""
OOPMAX scenario tests for cost estimation service.

Tests both direct service calls and HTTP API endpoints for OOPMAX scenarios.
"""
import json
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

from fastapi.testclient import TestClient

from app.main import app
from app.services.impl.cost_estimation_service_impl import CostEstimationServiceImpl
from app.schemas.cost_estimator_request import (
    CostEstimatorRequest,
    Service,
    SupportingService,
    Modifier,
    PlaceOfService,
    ProviderInfo,
    Speciality,
    ProviderNetworks,
    ProviderNetworkParticipation,
)
from app.models.rate_criteria import NegotiatedRate
from app.schemas.benefit_response import (
    BenefitApiResponse,
    ServiceInfoItem,
    ServiceCodeInfoItem,
    PlaceOfServiceItem,
    ProviderTypeItem,
    ProviderSpecialtyItem,
    Benefit,
    BenefitTier,
    Prerequisite,
    ServiceProviderItem,
    Coverage,
)
from app.schemas.accumulator_response import (
    AccumulatorResponse,
    ReadAccumulatorsResponse,
    Memberships,
    Member,
    MembershipIdentifier,
)
from app.models.selected_benefit import SelectedBenefit, SelectedCoverage
from app.core.base import InsuranceContext


def _build_min_request() -> CostEstimatorRequest:
    """Build a minimal cost estimation request for testing."""
    service = Service(
        code="99214",
        type="CPT4",
        description="Office visit",
        supportingService=SupportingService(code="", type=""),
        modifier=Modifier(modifierCode=""),
        diagnosisCode="Z00.00",
        placeOfService=PlaceOfService(code="11"),
    )

    provider = ProviderInfo(
        serviceLocation="001",
        providerType="Physician",
        speciality=Speciality(code=""),
        taxIdentificationNumber="123456789",
        taxIdQualifier="TIN",
        providerNetworks=ProviderNetworks(networkID="NET1"),
        providerIdentificationNumber="PRV123",
        nationalProviderId="1111111111",
        providerNetworkParticipation=ProviderNetworkParticipation(providerTier="Tier1"),
    )

    return CostEstimatorRequest(
        membershipId="MEM1",
        zipCode="02115",
        benefitProductType="Commercial",
        languageCode="EN",
        service=service,
        providerInfo=[provider],
    )


def _build_benefit_api_response() -> BenefitApiResponse:
    """Build a minimal benefit API response for testing."""
    service_info_item = ServiceInfoItem(
        serviceCodeInfo=[ServiceCodeInfoItem(code="99214", type="CPT4")],
        placeOfService=[PlaceOfServiceItem(code="11")],
        providerType=[ProviderTypeItem(code="Physician")],
        providerSpecialty=[ProviderSpecialtyItem(code="")],
        benefit=[
            Benefit(
                benefitName="Office Visit",
                benefitCode=1001,
                isInitialBenefit="N",
                benefitTier=BenefitTier(benefitTierName="Tier1"),
                networkCategory="InNetwork",
                prerequisites=[Prerequisite()],
                benefitProvider="GEN",
                serviceProvider=[ServiceProviderItem()],
                coverages=[
                    Coverage(
                        sequenceNumber=1,
                        benefitDescription="Office visit",
                        costShareCopay=20.0,
                        costShareCoinsurance=0.0,
                        copayAppliesOutOfPocket="Y",
                        coinsAppliesOutOfPocket="N",
                        deductibleAppliesOutOfPocket="N",
                        deductibleAppliesOutOfPocketOtherIndicator="N",
                        copayCountToDeductibleIndicator="N",
                        copayContinueWhenDeductibleMetIndicator="N",
                        copayContinueWhenOutOfPocketMaxMetIndicator="N",
                        coinsuranceToOutOfPocketOtherIndicator="N",
                        copayToOutofPocketOtherIndicator="N",
                        isDeductibleBeforeCopay="N",
                        benefitLimitation="N",
                        isServiceCovered="Y",
                        relatedAccumulators=[],
                    )
                ],
            )
        ],
    )
    return BenefitApiResponse(serviceInfo=[service_info_item])


def _build_selected_benefit() -> SelectedBenefit:
    """Build a selected benefit for testing."""
    coverage = SelectedCoverage(
        sequenceNumber=1,
        benefitDescription="Office visit",
        costShareCopay=20.0,
        costShareCoinsurance=0.0,
        copayAppliesOutOfPocket="Y",
        coinsAppliesOutOfPocket="N",
        deductibleAppliesOutOfPocket="N",
        deductibleAppliesOutOfPocketOtherIndicator="N",
        copayCountToDeductibleIndicator="N",
        copayContinueWhenDeductibleMetIndicator="N",
        copayContinueWhenOutOfPocketMaxMetIndicator="N",
        coinsuranceToOutOfPocketOtherIndicator="N",
        copayToOutofPocketOtherIndicator="N",
        isDeductibleBeforeCopay="N",
        benefitLimitation="N",
        isServiceCovered="Y",
        matchedAccumulators=[],
    )
    return SelectedBenefit(
        benefitName="Office Visit",
        benefitCode=1001,
        isInitialBenefit="N",
        benefitTier=BenefitTier(benefitTierName="Tier1"),
        networkCategory="InNetwork",
        prerequisites=[Prerequisite()],
        benefitProvider="GEN",
        serviceProvider=[ServiceProviderItem()],
        coverage=coverage,
    )


def _build_min_accumulator_response() -> AccumulatorResponse:
    """Build a minimal accumulator response for testing."""
    subscriber = Member(
        privacyRestriction="N",
        membershipIdentifier=MembershipIdentifier(
            idSource="HSQ", idValue="MEM1", idType="MBR", resourceId="MEM1"
        ),
        Status="Active",
        accumulators=[],
    )
    memberships = Memberships(subscriber=subscriber, dependents=[])
    return AccumulatorResponse(
        readAccumulatorsResponse=ReadAccumulatorsResponse(memberships=memberships)
    )


@pytest.mark.asyncio
async def test_estimate_cost_with_mocks():
    """Test cost estimation with direct service calls using mocks."""
    # Arrange
    request = _build_min_request()

    repo_mock = Mock()
    repo_mock.get_rate = AsyncMock(
        return_value=NegotiatedRate(
            paymentMethod="AMT",
            rate=120.0,
            rateType="AMOUNT",
            isRateFound=True,
            isProviderInfoFound=True,
        )
    )
    repo_mock.get_cached_pcp_specialty_codes = Mock(return_value=[])

    benefit_mock = Mock()
    benefit_mock.get_benefit = AsyncMock(return_value=_build_benefit_api_response())

    accumulator_mock = Mock()
    accumulator_mock.get_accumulator = AsyncMock(return_value=_build_min_accumulator_response())

    matcher_mock = Mock()
    matcher_mock.get_selected_benefits = Mock(return_value=[_build_selected_benefit()])

    calc_context = InsuranceContext()
    calc_context.member_pays = 30.0
    calc_context.amount_copay = 20.0
    calc_context.amount_coinsurance = 10.0

    calculation_mock = Mock()
    calculation_mock.find_highest_member_pay = Mock(return_value=calc_context)

    service = CostEstimationServiceImpl(
        repository=repo_mock,
        matcher_service=matcher_mock,
        benefit_service=benefit_mock,
        accumulator_service=accumulator_mock,
        calculation_service=calculation_mock,
    )

    # Act
    response = await service.estimate_cost(request)

    # Assert
    assert response is not None
    info_list = response.costEstimateResponse.costEstimateResponseInfo
    assert len(info_list) == 1

    info = info_list[0]
    assert info.cost.inNetworkCosts == 120.0
    assert info.coverage.costShareCopay == 20.0
    assert info.healthClaimLine.amountResponsibility == pytest.approx(30.0)
    assert info.healthClaimLine.amountpayable == pytest.approx(90.0)


def _load_scenario_data(scenario_name: str):
    """Load test data for a specific scenario."""
    base_dir = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "oop_max" / scenario_name
    
    # Load JSON fixtures
    cost_request_data = json.loads((base_dir / "cost_request.json").read_text())
    benefit_response_data = json.loads((base_dir / "benefit_response.json").read_text())
    accumulator_response_data = json.loads((base_dir / "accumulator_response.json").read_text())
    
    return cost_request_data, benefit_response_data, accumulator_response_data


def _build_mock_services(benefit_response_data, accumulator_response_data, service_amount):
    """Build mock services for testing."""
    benefit_api_response = BenefitApiResponse(**benefit_response_data)
    accumulator_response = AccumulatorResponse(**accumulator_response_data)
    
    return benefit_api_response, accumulator_response


def _make_api_call(cost_request_data, scenario_id):
    """Make API call with proper headers."""
    client = TestClient(app)
    headers = {
        "Content-Type": "application/json",
        "x-global-transaction-id": f"oopmax-{scenario_id}",
        "x-clientrefid": f"oopmax-client-{scenario_id}",
    }
    
    return client.post("/costestimator/v1/rate", json=cost_request_data, headers=headers)


def _save_cost_response_json(scenario_name, info, cost_request_data):
    """Save the cost estimation response as cost_response.json file."""
    # Write the cost_response.json file directly with the response data
    cost_response_path = Path(f"tests/mock-data/mock-api-test-data/oop_max/{scenario_name}/cost_response.json")
    with open(cost_response_path, 'w') as f:
        json.dump(info, f, indent=2)
    



def _setup_mocks_and_run_scenario(scenario_name, scenario_id, service_amount):
    """Common method to setup mocks and run scenario test."""
    # Load scenario data
    cost_request_data, benefit_response_data, accumulator_response_data = _load_scenario_data(scenario_name)
    
    # Build mock services
    benefit_api_response, accumulator_response = _build_mock_services(benefit_response_data, accumulator_response_data, service_amount)

    # Mock external services
    with patch('app.services.impl.benefit_service_impl.BenefitServiceImpl.get_benefit') as mock_benefit, \
         patch('app.services.impl.accumulator_service_impl.AccumulatorServiceImpl.get_accumulator') as mock_accumulator, \
         patch('app.repository.impl.cost_estimator_repository_impl.CostEstimatorRepositoryImpl.get_rate') as mock_rate, \
         patch('app.core.session_manager.SessionManager.get_token') as mock_token:
        
        # Configure mocks
        mock_token.return_value = "mock_token"
        mock_benefit.return_value = benefit_api_response
        mock_accumulator.return_value = accumulator_response
        mock_rate.return_value = NegotiatedRate(
            paymentMethod="AMT",
            rate=service_amount,
            rateType="AMOUNT",
            isRateFound=True,
            isProviderInfoFound=True,
        )

        # Make API call
        response = _make_api_call(cost_request_data, scenario_id)
        
        # Validate response
        assert response.status_code == 200
        body = response.json()
        assert "costEstimateResponse" in body
        
        # Validate service information
        assert body["costEstimateResponse"]["service"]["code"] == cost_request_data["service"]["code"]
        info_list = body["costEstimateResponse"]["costEstimateResponseInfo"]
        assert len(info_list) == 1

        info = info_list[0]
        
        return info, cost_request_data


def _get_log_text(caplog):
    """Extract log text from caplog fixture."""
    log_records = [record.message for record in caplog.records]
    return " ".join(log_records)


@pytest.mark.asyncio
async def test_scenario_3_1_no_oopmax_applies(caplog):
    """Test Scenario 3.1: No OOPMAX Applies (Family AND Individual)."""
    # Setup and run scenario using common method
    info, cost_request_data = _setup_mocks_and_run_scenario("scenario_3_1_no_oopmax_applies", "3.1", 900.0)
    
    # Get log text for validation
    log_text = _get_log_text(caplog)
    
    print(f"\n\nInfo 3.1 : {info}")

    print(f"\n\ncost_request_data 3.1 : {cost_request_data}")
    
    # Save the response as cost_response.json
    _save_cost_response_json("scenario_3_1_no_oopmax_applies", info, cost_request_data)

    # Validate Scenario 3.1: No OOPMAX Applies (Family AND Individual)
    # Coverage assertions
    assert info["coverage"]["isServiceCovered"] == "Y"  # isServiceCovered: Yes
    assert info["coverage"]["costShareCopay"] == 100.0  # costShareCopay: 100
    assert info["coverage"]["costShareCoinsurance"] == 20  # costShareCoinsurance: 20
    assert info["cost"]["inNetworkCosts"] == 900.0  # ServiceAmount: 900
    
    # Validate copay and deductible indicators from logs
    assert "copayCountToDeductibleIndicator='N'" in log_text, f"copayCountToDeductibleIndicator should be 'N'. Logs: {log_text}"
    assert "copayContinueWhenDeductibleMetIndicator='Y'" in log_text, f"copayContinueWhenDeductibleMetIndicator should be 'Y'. Logs: {log_text}"
    assert "isDeductibleBeforeCopay='Y'" in log_text, f"isDeductibleBeforeCopay should be 'Y'. Logs: {log_text}"
    
    # Validate accumulators
    accumulators = info.get("accumulators", [])
    assert len(accumulators) >= 2, f"Expected at least 2 accumulators, got {len(accumulators)}"
    
    # Check accumulator codes and levels
    codes = {(a["accumulator"]["code"], a["accumulator"]["level"]) for a in accumulators}
    assert ("Deductible", "Individual") in codes  # code = "Deductible", level="I": Yes
    assert ("Deductible", "Family") in codes  # code = "Deductible", level="F": Yes
    assert all(a["accumulator"]["code"].lower() != "limit" for a in accumulators)  # code = "limit": No
    assert all(a["accumulator"]["code"].lower() != "oopmax" for a in accumulators)  # code = "OOPMAX": No (both I and F)
    
    # Validate deductible calculated values
    ind_calculated = None
    fam_calculated = None
    
    for a in accumulators:
        code = a["accumulator"]["code"].lower()
        level = a["accumulator"]["level"].lower()
        if code == "deductible" and level == "individual":
            ind_calculated = a["accumulator"]["calculatedValue"]
        elif code == "deductible" and level == "family":
            fam_calculated = a["accumulator"]["calculatedValue"]

    # Validate deductible calculated values from scenario table
    assert ind_calculated is not None, "Deductible (Individual) calculatedValue not found"
    assert fam_calculated is not None, "Deductible (Family) calculatedValue not found"
    assert ind_calculated == 500.0  # DIcalculatedValue: 500
    assert fam_calculated == 1500.0  # DFcalculatedValue: 1500
    
    # Validate healthClaimLine data
    health_claim_line = info.get("healthClaimLine", {})
    assert health_claim_line.get("amountCopay") == 100.0, "amountCopay should be 100.0"
    assert health_claim_line.get("amountCoinsurance") == 60.0, "amountCoinsurance should be 60.0"
    assert health_claim_line.get("amountResponsibility") == 660.0, "amountResponsibility should be 660.0"
    assert health_claim_line.get("amountpayable") == 240.0, "amountpayable should be 240.0"
    
    # Validate that no OOPMAX accumulator appears in response object
    oopmax_accumulators = [a for a in accumulators if a["accumulator"]["code"].lower() == "oopmax"]
    assert len(oopmax_accumulators) == 0, f"Expected no OOPMAX accumulators in response object, got {len(oopmax_accumulators)}"

@pytest.mark.asyncio
async def test_scenario_3_2_oopmax_family_met_no_copay_after(caplog):
    """Test Scenario 3.2: OOPMAX Family is met, No Copay after OOPMAX met."""
    # Setup and run scenario using common method
    info, cost_request_data = _setup_mocks_and_run_scenario("scenario_3_2_family_met_no_copay_after", "3.2", 900.0)

    # Get log text for validation
    log_text = _get_log_text(caplog)

    print(f"\n\nInfo 3.2 : {info}")

    _save_cost_response_json("scenario_3_2_family_met_no_copay_after", info, cost_request_data)

    # Validate Scenario 3.2: OOPMAX Family is met, No Copay after OOPMAX met
    # Coverage assertions
    assert info["coverage"]["isServiceCovered"] == "Y"  # isServiceCovered: Yes
    assert info["coverage"]["costShareCopay"] == 100.0  # costShareCopay: 100
    assert info["coverage"]["costShareCoinsurance"] == 20  # costShareCoinsurance: 20
    assert info["cost"]["inNetworkCosts"] == 900.0  # ServiceAmount: 900
    
    # Validate copay and deductible indicators from logs
    assert "copayCountToDeductibleIndicator='N'" in log_text, f"copayCountToDeductibleIndicator should be 'N'. Logs: {log_text}"
    assert "copayContinueWhenDeductibleMetIndicator='Y'" in log_text, f"copayContinueWhenDeductibleMetIndicator should be 'Y'. Logs: {log_text}"
    assert "copayContinueWhenOutOfPocketMaxMetIndicator='N'" in log_text, f"copayContinueWhenOutOfPocketMaxMetIndicator should be 'N'. Logs: {log_text}"
    assert "isDeductibleBeforeCopay='Y'" in log_text, f"isDeductibleBeforeCopay should be 'Y'. Logs: {log_text}"
    
    # Validate out-of-pocket indicators from logs
    assert "copayAppliesOutOfPocket='Y'" in log_text, "copayAppliesOutOfPocket should be 'Y'"
    assert "coinsAppliesOutOfPocket='Y'" in log_text, "coinsAppliesOutOfPocket should be 'Y'"
    assert "deductibleAppliesOutOfPocket='Y'" in log_text, "deductibleAppliesOutOfPocket should be 'Y'"
    
    # Validate accumulators - OOPMAX accumulators are processed but not included in final response
    # when OOPMAX is met (this is expected behavior)
    accumulators = info.get("accumulators", [])
    assert len(accumulators) == 0, f"Expected 0 accumulators when OOPMAX is met, got {len(accumulators)}"
    
    # Validate that OOPMAX accumulators were processed (they appear in matchedAccumulators in logs)
    assert "OOPMAX" in log_text, "OOPMAX accumulators should be processed"
    assert "calculatedValue=300.0" in log_text, "OOPMAX Individual calculatedValue should be 300.0"
    assert "calculatedValue=0.0" in log_text, "OOPMAX Family calculatedValue should be 0.0"
    
    # Validate OOPMAX Individual and Family are both present (Yes/Yes from scenario table)
    assert "code='OOPMAX'" in log_text and "level='Individual'" in log_text, "OOPMAX Individual should be present"
    assert "code='OOPMAX'" in log_text and "level='Family'" in log_text, "OOPMAX Family should be present"
    
    # Validate calculated values from scenario table
    # OOPMAXIcalculatedValue: 300, OOPMAXFcalculatedValue: 0
    assert "calculatedValue=300.0" in log_text, "OOPMAXIcalculatedValue should be 300"
    assert "calculatedValue=0.0" in log_text, "OOPMAXFcalculatedValue should be 0"
    
    # DIcalculatedValue: 0, DFcalculatedValue: 0 (no deductible applies in this scenario)
    # These are validated by the absence of deductible accumulators in the final response
    
    # Validate healthClaimLine data for scenario 3.2
    # When Family OOPMAX is met, member pays $0 (all amounts are 0.0, insurance pays full amount)
    health_claim_line = info.get("healthClaimLine", {})
    assert health_claim_line.get("amountCopay") == 0.0, "amountCopay should be 0.0 when OOPMAX is met"
    assert health_claim_line.get("amountCoinsurance") == 0.0, "amountCoinsurance should be 0.0 when OOPMAX is met"
    assert health_claim_line.get("amountResponsibility") == 0.0, "amountResponsibility should be 0.0 when OOPMAX is met"
    assert health_claim_line.get("amountpayable") == 900.0, "amountpayable should be 900.0 (full service amount) when OOPMAX is met"


# TODO: Add other scenarios (3.3, 3.4, 3.5, 3.6) following the same pattern

# def test_scenario_3_3_oopmax_individual_met_family_not(caplog):
#     """Test Scenario 3.3: OOPMAX Individual is met, No Copay after OOPMAX met."""
#     pass

# def test_scenario_3_4_oopmax_met_copay_continues_greater(caplog):
#     """Test Scenario 3.4: OOPMAX Individual OR Family is met, Copay continues after OOPMAX met, Copay > Service Amount."""
#     pass

# def test_scenario_3_5_oopmax_met_copay_continues_less(caplog):
#     """Test Scenario 3.5: OOPMAX Individual OR Family is met, Copay continues after OOPMAX met, Copay < Service Amount."""
#     pass

# def test_scenario_3_6_oopmax_not_met(caplog):
#     """Test Scenario 3.6: OOPMAX not met (Individual and Family)."""
#     pass