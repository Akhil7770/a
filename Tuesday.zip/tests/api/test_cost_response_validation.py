"""
Cost Response Validation Tests

This module contains comprehensive tests for validating the cost_response.json file
structure, content, and business logic calculations.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, List
from unittest.mock import patch, AsyncMock, MagicMock
import pytest
from fastapi.testclient import TestClient
from httpx import AsyncClient

from app.main import app


class TestCostResponseValidation:
    """Test class for cost response JSON validation."""
    
    @pytest.fixture(autouse=True)
    def setup_method(self):
        """Setup method to initialize test data paths."""
        self.base_path = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "deductible" / "no_deductible_applies"
        self.cost_response_file = "cost_response.json"
        self.cost_request_file = "cost_request.json"
    
    def load_cost_response(self) -> Dict[str, Any]:
        """Load cost response data from JSON file."""
        file_path = self.base_path / self.cost_response_file
        with open(file_path, 'r') as f:
            return json.load(f)
    
    def load_cost_request(self) -> Dict[str, Any]:
        """Load cost request data from JSON file."""
        file_path = self.base_path / self.cost_request_file
        with open(file_path, 'r') as f:
            return json.load(f)

    @pytest.fixture
    def mock_cost_response_service(self):
        """Mock service to return the actual cost_response.json data."""
        with patch('app.services.impl.cost_estimation_service_impl.CostEstimationServiceImpl.estimate_cost') as mock_estimate, \
             patch('app.services.token_service.TokenService.get_new_token') as mock_token, \
             patch('app.database.spanner_client.SpannerClient') as mock_spanner:
            
            # Mock token service
            mock_token.return_value = {
                "access_token": "mock_token_123",
                "expires_in": 3600,
                "token_type": "Bearer"
            }
            
            # Load and return the actual cost_response.json data as a dict
            cost_response_data = self.load_cost_response()
            
            # Mock the estimate method to return the JSON data directly
            mock_estimate.return_value = cost_response_data
            
            yield {
                'estimate': mock_estimate,
                'token': mock_token,
                'spanner': mock_spanner
            }
    
    @pytest.mark.api
    def test_cost_response_file_structure(self):
        """Test that cost_response.json has the correct overall structure."""
        cost_response = self.load_cost_response()
        
        # Test top-level structure
        assert "costEstimateResponse" in cost_response, "Missing costEstimateResponse"
        
        cost_estimate_response = cost_response["costEstimateResponse"]
        assert "service" in cost_estimate_response, "Missing service section"
        assert "costEstimateResponseInfo" in cost_estimate_response, "Missing costEstimateResponseInfo section"
        
        # Test costEstimateResponseInfo is a list with at least one item
        response_info = cost_estimate_response["costEstimateResponseInfo"]
        assert isinstance(response_info, list), "costEstimateResponseInfo should be a list"
        assert len(response_info) > 0, "costEstimateResponseInfo should not be empty"
    
    @pytest.mark.api
    def test_service_section_validation(self):
        """Test the service section of the cost response."""
        cost_response = self.load_cost_response()
        service = cost_response["costEstimateResponse"]["service"]
        
        # Required service fields
        required_fields = ["code", "type", "description", "supportingService", "modifier", "diagnosisCode", "placeOfService"]
        for field in required_fields:
            assert field in service, f"Missing required service field: {field}"
        
        # Validate specific values
        assert service["code"] == "21137", f"Expected service code 21137, got {service['code']}"
        assert service["type"] == "CPT4", f"Expected service type CPT4, got {service['type']}"
        
        # Validate nested structures
        assert "code" in service["placeOfService"], "Missing placeOfService code"
        assert service["placeOfService"]["code"] == "22", f"Expected place of service 22, got {service['placeOfService']['code']}"
    
    @pytest.mark.api
    def test_provider_info_validation(self):
        """Test the provider information in the cost response."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        provider_info = response_info["providerInfo"]
        
        # Required provider fields
        required_fields = ["serviceLocation", "providerType", "speciality", "taxIdentificationNumber", 
                          "taxIdQualifier", "providerNetworks", "providerIdentificationNumber", 
                          "nationalProviderId", "providerNetworkParticipation"]
        for field in required_fields:
            assert field in provider_info, f"Missing required provider field: {field}"
        
        # Validate specific values
        assert provider_info["serviceLocation"] == "0003543634", f"Expected serviceLocation 0003543634, got {provider_info['serviceLocation']}"
        assert provider_info["providerType"] == "HO", f"Expected providerType HO, got {provider_info['providerType']}"
        assert provider_info["providerIdentificationNumber"] == "0006170130", f"Expected provider ID 0006170130, got {provider_info['providerIdentificationNumber']}"
        
        # Validate nested structures
        assert "networkID" in provider_info["providerNetworks"], "Missing networkID in providerNetworks"
        assert provider_info["providerNetworks"]["networkID"] == "00387", f"Expected networkID 00387, got {provider_info['providerNetworks']['networkID']}"
    
    @pytest.mark.api
    def test_coverage_validation(self):
        """Test the coverage section of the cost response."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        coverage = response_info["coverage"]
        
        # Required coverage fields
        required_fields = ["isServiceCovered", "maxCoverageAmount", "costShareCopay", "costShareCoinsurance"]
        for field in required_fields:
            assert field in coverage, f"Missing required coverage field: {field}"
        
        # Validate specific values
        assert coverage["isServiceCovered"] == "Y", f"Expected service covered Y, got {coverage['isServiceCovered']}"
        assert coverage["costShareCopay"] == 0.0, f"Expected copay 0.0, got {coverage['costShareCopay']}"
        assert coverage["costShareCoinsurance"] == 20, f"Expected coinsurance 20, got {coverage['costShareCoinsurance']}"
    
    @pytest.mark.api
    def test_cost_validation(self):
        """Test the cost section of the cost response."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        cost = response_info["cost"]
        
        # Required cost fields
        required_fields = ["inNetworkCosts", "outOfNetworkCosts", "inNetworkCostsType"]
        for field in required_fields:
            assert field in cost, f"Missing required cost field: {field}"
        
        # Validate specific values
        assert cost["inNetworkCosts"] == 59.24, f"Expected inNetworkCosts 59.24, got {cost['inNetworkCosts']}"
        assert cost["outOfNetworkCosts"] == 0.0, f"Expected outOfNetworkCosts 0.0, got {cost['outOfNetworkCosts']}"
        assert cost["inNetworkCostsType"] == "PERCENTAGE", f"Expected inNetworkCostsType PERCENTAGE, got {cost['inNetworkCostsType']}"
    
    @pytest.mark.api
    def test_health_claim_line_validation(self):
        """Test the healthClaimLine section of the cost response."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        health_claim_line = response_info["healthClaimLine"]
        
        # Required health claim line fields
        required_fields = ["amountCopay", "amountCoinsurance", "amountResponsibility", "percentResponsibility", "amountpayable"]
        for field in required_fields:
            assert field in health_claim_line, f"Missing required healthClaimLine field: {field}"
        
        # Validate specific values
        assert health_claim_line["amountCopay"] == 0.0, f"Expected amountCopay 0.0, got {health_claim_line['amountCopay']}"
        assert health_claim_line["amountCoinsurance"] == 0.0, f"Expected amountCoinsurance 0.0, got {health_claim_line['amountCoinsurance']}"
        assert health_claim_line["amountResponsibility"] == 0.0, f"Expected amountResponsibility 0.0, got {health_claim_line['amountResponsibility']}"
        assert health_claim_line["percentResponsibility"] == 59.24, f"Expected percentResponsibility 59.24, got {health_claim_line['percentResponsibility']}"
        assert health_claim_line["amountpayable"] == 0.0, f"Expected amountpayable 0.0, got {health_claim_line['amountpayable']}"
    
    @pytest.mark.api
    def test_accumulators_validation(self):
        """Test the accumulators section of the cost response."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        accumulators = response_info["accumulators"]
        
        # Should have exactly 4 accumulators
        assert len(accumulators) == 4, f"Expected 4 accumulators, got {len(accumulators)}"
        
        # Validate each accumulator structure
        for i, accumulator_info in enumerate(accumulators):
            assert "accumulator" in accumulator_info, f"Missing accumulator in item {i}"
            assert "accumulatorCalculation" in accumulator_info, f"Missing accumulatorCalculation in item {i}"
            
            accumulator = accumulator_info["accumulator"]
            calculation = accumulator_info["accumulatorCalculation"]
            
            # Required accumulator fields
            accumulator_fields = ["code", "level", "limitValue", "calculatedValue"]
            for field in accumulator_fields:
                assert field in accumulator, f"Missing accumulator field {field} in item {i}"
            
            # Required calculation fields
            calculation_fields = ["remainingValue", "appliedValue"]
            for field in calculation_fields:
                assert field in calculation, f"Missing calculation field {field} in item {i}"
    
    @pytest.mark.api
    def test_deductible_accumulators_specific_values(self):
        """Test the specific deductible accumulator values."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        accumulators = response_info["accumulators"]
        
        # Find deductible accumulators
        deductible_accumulators = [acc for acc in accumulators if acc["accumulator"]["code"] == "Deductible"]
        assert len(deductible_accumulators) == 2, f"Expected 2 deductible accumulators, got {len(deductible_accumulators)}"
        
        # Validate Individual Deductible
        individual_deductible = next((acc for acc in deductible_accumulators if acc["accumulator"]["level"] == "Individual"), None)
        assert individual_deductible is not None, "Missing Individual deductible accumulator"
        
        ind_acc = individual_deductible["accumulator"]
        ind_calc = individual_deductible["accumulatorCalculation"]
        
        assert ind_acc["limitValue"] == 3500.0, f"Expected Individual deductible limit 3500.0, got {ind_acc['limitValue']}"
        assert ind_acc["calculatedValue"] == 0.0, f"Expected Individual deductible calculated 0.0, got {ind_acc['calculatedValue']}"
        assert ind_calc["remainingValue"] == 0.0, f"Expected Individual deductible remaining 0.0, got {ind_calc['remainingValue']}"
        assert ind_calc["appliedValue"] == 0.0, f"Expected Individual deductible applied 0.0, got {ind_calc['appliedValue']}"
        
        # Validate Family Deductible
        family_deductible = next((acc for acc in deductible_accumulators if acc["accumulator"]["level"] == "Family"), None)
        assert family_deductible is not None, "Missing Family deductible accumulator"
        
        fam_acc = family_deductible["accumulator"]
        fam_calc = family_deductible["accumulatorCalculation"]
        
        assert fam_acc["limitValue"] == 7000.0, f"Expected Family deductible limit 7000.0, got {fam_acc['limitValue']}"
        assert fam_acc["calculatedValue"] == 3500.0, f"Expected Family deductible calculated 3500.0, got {fam_acc['calculatedValue']}"
        assert fam_calc["remainingValue"] == 3500.0, f"Expected Family deductible remaining 3500.0, got {fam_calc['remainingValue']}"
        assert fam_calc["appliedValue"] == 0.0, f"Expected Family deductible applied 0.0, got {fam_calc['appliedValue']}"
    
    @pytest.mark.api
    def test_oop_max_accumulators_specific_values(self):
        """Test the specific OOP Max accumulator values."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        accumulators = response_info["accumulators"]
        
        # Find OOP Max accumulators
        oop_accumulators = [acc for acc in accumulators if acc["accumulator"]["code"] == "OOP Max"]
        assert len(oop_accumulators) == 2, f"Expected 2 OOP Max accumulators, got {len(oop_accumulators)}"
        
        # Validate Individual OOP Max
        individual_oop = next((acc for acc in oop_accumulators if acc["accumulator"]["level"] == "Individual"), None)
        assert individual_oop is not None, "Missing Individual OOP Max accumulator"
        
        ind_acc = individual_oop["accumulator"]
        ind_calc = individual_oop["accumulatorCalculation"]
        
        assert ind_acc["limitValue"] == 7000.0, f"Expected Individual OOP Max limit 7000.0, got {ind_acc['limitValue']}"
        assert ind_acc["calculatedValue"] == 3500.0, f"Expected Individual OOP Max calculated 3500.0, got {ind_acc['calculatedValue']}"
        assert ind_calc["remainingValue"] == 3500.0, f"Expected Individual OOP Max remaining 3500.0, got {ind_calc['remainingValue']}"
        assert ind_calc["appliedValue"] == 0.0, f"Expected Individual OOP Max applied 0.0, got {ind_calc['appliedValue']}"
        
        # Validate Family OOP Max
        family_oop = next((acc for acc in oop_accumulators if acc["accumulator"]["level"] == "Family"), None)
        assert family_oop is not None, "Missing Family OOP Max accumulator"
        
        fam_acc = family_oop["accumulator"]
        fam_calc = family_oop["accumulatorCalculation"]
        
        assert fam_acc["limitValue"] == 14000.0, f"Expected Family OOP Max limit 14000.0, got {fam_acc['limitValue']}"
        assert fam_acc["calculatedValue"] == 10500.0, f"Expected Family OOP Max calculated 10500.0, got {fam_acc['calculatedValue']}"
        assert fam_calc["remainingValue"] == 10500.0, f"Expected Family OOP Max remaining 10500.0, got {fam_calc['remainingValue']}"
        assert fam_calc["appliedValue"] == 0.0, f"Expected Family OOP Max applied 0.0, got {fam_calc['appliedValue']}"
    
    @pytest.mark.api
    def test_cost_response_json_structure_validation(self):
        """Test the JSON structure and content of the cost response without API integration."""
        # Load both request and response data
        request_data = self.load_cost_request()
        response_data = self.load_cost_response()
        
        # Validate that request and response are consistent
        assert request_data["service"]["code"] == response_data["costEstimateResponse"]["service"]["code"], \
            "Service codes should match between request and response"
        
        # Validate response structure in detail
        cost_estimate_response = response_data["costEstimateResponse"]
        response_info = cost_estimate_response["costEstimateResponseInfo"][0]
        
        # Validate all main sections exist
        required_sections = ["providerInfo", "coverage", "cost", "healthClaimLine", "accumulators"]
        for section in required_sections:
            assert section in response_info, f"Missing required section: {section}"
        
        # Validate accumulator structure
        accumulators = response_info["accumulators"]
        assert len(accumulators) == 4, "Should have exactly 4 accumulators"
        
        accumulator_types = [(acc["accumulator"]["code"], acc["accumulator"]["level"]) for acc in accumulators]
        expected_types = [
            ("Deductible", "Individual"), ("Deductible", "Family"),
            ("OOP Max", "Individual"), ("OOP Max", "Family")
        ]
        for expected_type in expected_types:
            assert expected_type in accumulator_types, f"Missing accumulator type: {expected_type}"
    
    @pytest.mark.api
    def test_cost_response_business_logic_validation(self):
        """Test business logic consistency in the cost response."""
        cost_response = self.load_cost_response()
        response_info = cost_response["costEstimateResponse"]["costEstimateResponseInfo"][0]
        
        # Test that percentage responsibility matches in network costs
        cost_section = response_info["cost"]
        health_claim = response_info["healthClaimLine"]
        
        assert cost_section["inNetworkCosts"] == health_claim["percentResponsibility"], \
            "inNetworkCosts should match percentResponsibility for percentage-based costs"
        
        # Test that when copay is 0, amountCopay should also be 0
        coverage = response_info["coverage"]
        if coverage["costShareCopay"] == 0.0:
            assert health_claim["amountCopay"] == 0.0, "amountCopay should be 0 when costShareCopay is 0"
        
        # Test accumulator consistency
        accumulators = response_info["accumulators"]
        for acc_info in accumulators:
            acc = acc_info["accumulator"]
            calc = acc_info["accumulatorCalculation"]
            
            # Remaining + Applied should not exceed limit for most cases
            # (Note: This is a business rule that may vary, adjust as needed)
            if calc["appliedValue"] > 0:
                total_used = calc["appliedValue"] + (acc["limitValue"] - calc["remainingValue"])
                assert total_used <= acc["limitValue"], \
                    f"Total accumulator usage should not exceed limit for {acc['code']} {acc['level']}"


@pytest.mark.api
class TestCostResponseUtilities:
    """Utility tests for cost response validation."""
    
    def test_cost_response_file_exists(self):
        """Test that the cost_response.json file exists and is readable."""
        base_path = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "deductible" / "no_deductible_applies"
        cost_response_path = base_path / "cost_response.json"
        
        assert cost_response_path.exists(), "cost_response.json file not found"
        assert cost_response_path.is_file(), "cost_response.json should be a file"
        
        # Test file is readable and valid JSON
        try:
            with open(cost_response_path, 'r') as f:
                json.load(f)
        except json.JSONDecodeError as e:
            pytest.fail(f"cost_response.json contains invalid JSON: {e}")
    
    def test_cost_response_json_validity(self):
        """Test that cost response is valid JSON with expected top-level structure."""
        base_path = Path(__file__).parent.parent / "mock-data" / "mock-api-test-data" / "deductible" / "no_deductible_applies"
        
        with open(base_path / "cost_response.json", 'r') as f:
            cost_response = json.load(f)
        
        # Test basic JSON structure without Pydantic validation
        assert isinstance(cost_response, dict), "Cost response should be a dictionary"
        assert "costEstimateResponse" in cost_response, "Missing costEstimateResponse"
        
        cost_estimate = cost_response["costEstimateResponse"]
        assert isinstance(cost_estimate, dict), "costEstimateResponse should be a dictionary"
        assert "service" in cost_estimate, "Missing service in costEstimateResponse"
        assert "costEstimateResponseInfo" in cost_estimate, "Missing costEstimateResponseInfo"
        
        # Test that costEstimateResponseInfo contains expected structure
        response_info = cost_estimate["costEstimateResponseInfo"]
        assert isinstance(response_info, list), "costEstimateResponseInfo should be a list"
        assert len(response_info) > 0, "costEstimateResponseInfo should not be empty"
        
        first_info = response_info[0]
        expected_keys = ["providerInfo", "coverage", "cost", "healthClaimLine", "accumulators"]
        for key in expected_keys:
            assert key in first_info, f"Missing key {key} in costEstimateResponseInfo"

