#!/usr/bin/env python3
"""
Tests for the DeductibleCoInsuranceHandler class and interface.
"""

import sys
import os
from unittest.mock import Mock

import pytest
from app.services.handlers.deductible_co_insurance_handler import DeductibleCoInsuranceHandler
from tests.services.handlers.test_data import (
    mock_matched_accumulator_individual_oopmax,
    mock_matched_accumulator_family_oopmax,
    mock_matched_accumulator_individual_deductible,
    mock_matched_accumulator_family_deductible,
    mock_handle,
    MockBenefit,
    MockCoverage,
    assert_insurance_context,
)

# Add the project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, project_root)


@pytest.fixture
def deductible_coinsurance_handler_fixture() -> DeductibleCoInsuranceHandler:
    """Fixture for DeductibleCoInsuranceHandler"""
    return DeductibleCoInsuranceHandler()


class TestDeductibleCoInsuranceHandler:
    """Test the DeductibleCoInsuranceHandler implementation"""

    def test_cost_share_coinsurance_less_than_zero(
        self,
        deductible_coinsurance_handler_fixture: DeductibleCoInsuranceHandler,
    ):
        """Test handle with cost share coinsurance less than zero"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        benefit = mock_handle(
            handler=deductible_coinsurance_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test benefit with OOP max"),
            matched_accumulators=[matched_accum],
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=benefit,
            service_amount=200,
            expected_values={
                "is_service_covered": True,  # Service should be covered
                "calculation_complete": True,  # Calculation should be complete
            },
            show=True,
        )

        # Assert that the appropriate trace message was generated
        trace_found = False
        for trace in benefit.trace_entries:
            if "_apply_member_pays_no_co_insurance" in trace.step:
                trace_found = True
                print(f"_apply_member_pays_no_co_insurance trace found: [{trace.step}] {trace.description}")
                break

        assert trace_found, "Expected _apply_member_pays_no_co_insurance trace message not found"

        print("Test completed successfully. Cost share coinsurance less than zero applied correctly.")

    def test_cost_share_coinsurance_greater_than_zero(
        self,
        deductible_coinsurance_handler_fixture: DeductibleCoInsuranceHandler,
    ):
        """Test handle with cost share coinsurance greater than zero"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        benefit = mock_handle(
            handler=deductible_coinsurance_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCoinsurance=20.0,
                coinsAppliesOutOfPocket="N"
            ),
            matched_accumulators=[matched_accum],
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=benefit,
            service_amount=200,
            expected_values={
                "is_service_covered": True,  # Service should be covered
                "calculation_complete": True,  # Calculation should be complete
                "member_pays": 40.0,  # Member pays should be 40 (20% of 200)
                "service_amount": 160.0,  # Service amount should be reduced to 160
                "amount_coinsurance": 40.0,  # Coinsurance amount should be 40
            },
            show=True,
        )

        # Assert that the appropriate trace message was generated
        trace_found = False
        for trace in benefit.trace_entries:
            if "_apply_member_pays_co_insurance_and_not_applied_to_oopmax" in trace.step:
                trace_found = True
                print(f"_apply_member_pays_co_insurance_and_not_applied_to_oopmax trace found: [{trace.step}] {trace.description}")
                break

        assert trace_found, "Expected _apply_member_pays_co_insurance_and_not_applied_to_oopmax trace message not found"

        print("Test completed successfully. Cost share coinsurance greater than zero applied correctly.")

    def test_cost_share_coinsurance_greater_than_zero_and_applied_to_oopmax_and_coinsurance_greater_than_service_amount(
        self,
        deductible_coinsurance_handler_fixture: DeductibleCoInsuranceHandler,
    ):
        """Test handle with cost share coinsurance greater than zero and applied to oopmax and coinsurance greater than service amount"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=100)
        matched_accum3 = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        benefit = mock_handle(
            handler=deductible_coinsurance_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCoinsurance=2000.0,
                coinsAppliesOutOfPocket="Y"
            ),
            matched_accumulators=[matched_accum, matched_accum2, matched_accum3],
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=benefit,
            service_amount=200,
            expected_values={
                "is_service_covered": True,  # Service should be covered
                "member_pays": 0.0,  # Member pays should remain 0 (no processing done)
                "service_amount": 200.0,  # Service amount should remain unchanged
                "oopmax_individual_calculated": 100.0,  # OOP max individual should remain unchanged
                "oopmax_family_calculated": 100.0,  # OOP max family should remain unchanged
                "deductible_individual_calculated": 0, # Deductible individual should be 0
                "deductible_family_calculated": None, # Deductible family should be None
            },
            show=True,
        )

        # Assert that the appropriate trace message was generated
        trace_found = False
        for trace in benefit.trace_entries:
            if "The co-insurance amount can never be greater than the service amount" in trace.description:
                trace_found = True
                print(f"Expected trace message found: [{trace.step}] {trace.description}")
                break

        assert trace_found, "Expected trace message about coinsurance greater than service amount not found"

        print("Test completed successfully. Coinsurance greater than service amount handled correctly.")

    def test_coinsurance_amount_lesser_than_service_amount_and_lesser_than_oopmax(
        self,
        deductible_coinsurance_handler_fixture: DeductibleCoInsuranceHandler,
    ):
        """Test coinsurance amount lesser than service amount and lesser than oopmax"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=50)
        matched_accum3 = mock_matched_accumulator_individual_oopmax(calculatedValue=100)
        benefit = mock_handle(
            handler=deductible_coinsurance_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCoinsurance=20.0,
                coinsAppliesOutOfPocket="Y"
            ),
            matched_accumulators=[matched_accum, matched_accum2, matched_accum3],
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=benefit,
            service_amount=200,
            expected_values={
                "is_service_covered": True,  # Service should be covered
                "calculation_complete": True,  # Calculation should be complete
                "member_pays": 40.0,  # Member pays should be 40 (20% of 200)
                "service_amount": 160.0,  # Service amount should be reduced to 160
                "amount_coinsurance": 40.0,  # Coinsurance amount should be 40
                "oopmax_individual_calculated": 60.0,  # OOP max individual should be reduced to 60
                "oopmax_family_calculated": 10.0,  # OOP max family should be reduced to 10
                "deductible_individual_calculated": 0, # Deductible individual should be 0
                "deductible_family_calculated": None, # Deductible family should be None
            },
            show=True,
        )

        # Assert that the appropriate trace message was generated
        trace_found = False
        for trace in benefit.trace_entries:
            if "_apply_member_pays_co_insurance_and_applied_to_oopmax" in trace.step:
                trace_found = True
                print(f"_apply_member_pays_co_insurance_and_applied_to_oopmax trace found: [{trace.step}] {trace.description}")
                break

        assert trace_found, "Expected _apply_member_pays_co_insurance_and_applied_to_oopmax trace message not found"

        print("Test completed successfully. Coinsurance amount lesser than service amount and lesser than oopmax applied correctly.")

    def test_coinsurance_amount_lesser_than_service_amount_and_greater_than_oopmax(
        self,
        deductible_coinsurance_handler_fixture: DeductibleCoInsuranceHandler,
    ):
        """Test coinsurance amount lesser than service amount and greater than oopmax"""
        matched_accum = mock_matched_accumulator_individual_deductible(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=50)
        matched_accum3 = mock_matched_accumulator_individual_oopmax(calculatedValue=50)
        benefit = mock_handle(
            handler=deductible_coinsurance_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCoinsurance=40.0,
                coinsAppliesOutOfPocket="Y"
            ),
            matched_accumulators=[matched_accum, matched_accum2, matched_accum3],
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=benefit,
            service_amount=200,
            expected_values={
                "is_service_covered": True,  # Service should be covered
                "calculation_complete": True,  # Calculation should be complete
                "member_pays": 50.0,  # Member pays should be 50 (min oopmax)
                "service_amount": 150.0,  # Service amount should be reduced to 150
                "oopmax_individual_calculated": 0.0,  # OOP max individual should be 0
                "oopmax_family_calculated": 0.0,  # OOP max family should be 0
                "deductible_individual_calculated": 0, # Deductible individual should be 0
                "deductible_family_calculated": None, # Deductible family should be None
                "amount_coinsurance": 50.0, # Amount coinsurance should be 50

            },
            show=True,
        )

        # Assert that the appropriate trace message was generated
        trace_found = False
        for trace in benefit.trace_entries:
            if "_apply_member_pays_oopmax_difference" in trace.step:
                trace_found = True
                print(f"_apply_member_pays_oopmax_difference trace found: [{trace.step}] {trace.description}")
                break

        assert trace_found, "Expected _apply_member_pays_oopmax_difference trace message not found"

        print("Test completed successfully. Coinsurance amount lesser than service amount and greater than oopmax applied correctly.")


if __name__ == "__main__":
    pytest.main([__file__])
    

        

