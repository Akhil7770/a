#!/usr/bin/env python3
"""
Tests for the OOPMaxCopayHandler class and interface.
"""

import sys
import os
from unittest.mock import Mock

import pytest
from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.services.calculation_service import (
    CalculationServiceInterface,
)
from tests.services.handlers.test_data import (
    mock_matched_accumulator_individual_oopmax,
    mock_matched_accumulator_family_oopmax,
    mock_matched_accumulator_individual_deductible,
    mock_main,
    MockBenefit,
    MockCoverage,
    assert_insurance_context,
)

# Add the project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, project_root)


@pytest.fixture
def calculation_service_fixture() -> CalculationServiceImpl:
    """Fixture for CalculationService"""
    return CalculationServiceImpl()


class TestCalculationService:
    """Test the CalculationService implementation"""

    def setup_method(self):
        """Set up test fixtures"""
        self.calculation_service = CalculationServiceImpl()

    def test_calculation_service_implements_interface(self):
        """Test that CalculationService implements the interface"""
        assert isinstance(self.calculation_service, CalculationServiceInterface)

    def test_calculation_service_has_chain(self):
        """Test that CalculationService has a calculation chain"""
        assert hasattr(self.calculation_service, "chain")
        assert self.calculation_service.chain is not None

    def test_find_highest_member_pay_oopmax_benefit_copay_greater_than_zero(
        self,
        calculation_service_fixture: CalculationServiceImpl,
    ):
        """Test find_highest_member_pay with benefit that has OOP max = 0 and copay > 0"""
        
        # Create a benefit with OOP max accumulator
        # Create a benefit with limit accumulator with calculatedValue=0 (only override this value)
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=0)
        
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max",
                costShareCopay=25.0,
                copayContinueWhenOutOfPocketMaxMetIndicator="N",
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )

        service_amount = 200
        result = calculation_service_fixture.find_highest_member_pay(
            service_amount, [benefit]
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=result,
            service_amount=service_amount,
            expected_values={
                "member_pays": 0,  # Member pays 0 when OOP max is met
                "is_service_covered": True,  # Service should be covered
                "oopmax_individual_calculated": 0,  # OOP max individual should be 0
                "oopmax_family_calculated": 0,  # OOP max family should be 0
                "calculation_complete": True  # Calculation should be complete
            },
            show=True,
        )

        # Assert that _apply_zero_copay was called (look for its trace message)
        zero_copay_trace_found = False
        for trace in result.trace_entries:
            if "_apply_zero_copay" in trace.step:
                zero_copay_trace_found = True
                print(f"_apply_zero_copay trace found: [{trace.step}] {trace.description}")
                break

        assert zero_copay_trace_found, "Expected _apply_zero_copay trace message not found"

        print("Test completed successfully. OOP max copay greater than zero applied correctly.")

    def test_find_highest_member_pay_with_oopmax_benefit_copay_lesser_than_service_amount(
        self,
        calculation_service_fixture: CalculationServiceImpl,
    ):
        """Test find_highest_member_pay with benefit that has OOP max = 0 and copay < service amount"""
        
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=0)
        
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", 
                costShareCopay=100.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )

        service_amount = 200
        result = calculation_service_fixture.find_highest_member_pay(
            service_amount, [benefit]
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=result,
            service_amount=service_amount,
            expected_values={
                "member_pays": 100,  # Member pays the copay amount
                "is_service_covered": True,  # Service should be covered
                "oopmax_individual_calculated": 0,  # OOP max individual should be 0
                "oopmax_family_calculated": 0,  # OOP max family should be 0
                "amount_copay": 100, # should be 100
                "cost_share_copay": 0, # should be 0
                "calculation_complete": True  # Calculation should be complete
            },
            show=True,
        )

        # Assert that _apply_member_pays_cost_share_amount was called (look for its trace message)
        cost_share_trace_found = False
        for trace in result.trace_entries:
            if "_apply_member_pays_cost_share_amount" in trace.step:
                cost_share_trace_found = True
                print(f"_apply_member_pays_cost_share_amount trace found: [{trace.step}] {trace.description}")
                break

        assert cost_share_trace_found, "Expected _apply_member_pays_cost_share_amount trace message not found"

        # Verify cost share copay is applied correctly
        assert result.cost_share_copay == 0, f"Expected cost_share_copay to be 0, got {result.cost_share_copay}"

        print("Test completed successfully. OOP max copay lesser than service amount applied correctly.")

    def test_find_highest_member_pay_with_oopmax_benefit_copay_greater_than_service_amount(
        self,
        calculation_service_fixture: CalculationServiceImpl,
    ):
        """Test find_highest_member_pay with benefit that has OOP max = 0 and copay > service amount"""
        
        # Create a benefit with OOP max accumulator
        matched_accum = mock_matched_accumulator_individual_oopmax(calculatedValue=0)
        matched_accum2 = mock_matched_accumulator_family_oopmax(calculatedValue=0)
        
        benefit = mock_main(
            mock_benefit=MockBenefit(
                benefitName="Test benefit with OOP max", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test benefit with OOP max", 
                costShareCopay=300.0
            ),
            matched_accumulators=[matched_accum, matched_accum2],
        )

        service_amount = 200
        result = calculation_service_fixture.find_highest_member_pay(
            service_amount, [benefit]
        )

        # Use the improved assertion helper
        assert_insurance_context(
            insurance_context=result,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,  # Service amount should be 0 after processing
                "member_pays": 200,  # Member pays the full service amount
                "is_service_covered": True,  # Service should be covered
                "oopmax_individual_calculated": 0,  # OOP max individual should be 0
                "oopmax_family_calculated": 0,  # OOP max family should be 0
                "amount_copay": 0, # should be 0
                "cost_share_copay": 300, # should be 300
                "calculation_complete": True  # Calculation should be complete
            },
            show=True,
        )

        # Assert that _apply_member_pays_full_amount was called (look for its trace message)
        full_amount_trace_found = False
        for trace in result.trace_entries:
            if "_apply_member_pays_full_amount" in trace.step:
                full_amount_trace_found = True
                print(f"_apply_member_pays_full_amount trace found: [{trace.step}] {trace.description}")
                break

        assert full_amount_trace_found, "Expected _apply_member_pays_full_amount trace message not found"
        print("Test completed successfully. OOP max copay greater than service amount applied correctly.")
