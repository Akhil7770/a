from unittest.mock import Mock
from behave import given, when, then  # type: ignore
from app.services.handlers.deductible_handler import DeductibleHandler
from app.core.base import InsuranceContext


@given("an DeductibleHandler is created")
def step_create_deductible_handler(context):
    context.handler = DeductibleHandler()
    context.insurance_context = InsuranceContext()

    # Create a mock for the cost share handler
    mock_deductible_oopmax_handler = Mock()
    mock_deductible_oopmax_handler.handle.return_value = context.insurance_context

    context.handler.set_deductible_oopmax_handler(mock_deductible_oopmax_handler)
    context.mock_deductible_oopmax_handler = mock_deductible_oopmax_handler

    # Create a mock for the co pay handler
    mock_cost_share_co_pay_handler = Mock()
    mock_cost_share_co_pay_handler.handle.return_value = context.insurance_context

    context.handler.set_cost_share_co_pay_handler(mock_cost_share_co_pay_handler)
    context.mock_cost_share_co_pay_handler = mock_cost_share_co_pay_handler

    mock_deductible_cost_share_co_pay_handler = Mock()
    mock_deductible_cost_share_co_pay_handler.handle.return_value = context.insurance_context
    context.handler.set_deductible_cost_share_co_pay_handler(mock_deductible_cost_share_co_pay_handler)
    context.mock_deductible_cost_share_co_pay_handler = mock_deductible_cost_share_co_pay_handler

    mock_deductible_co_pay_handler = Mock()
    mock_deductible_co_pay_handler.handle.return_value = context.insurance_context
    context.handler.set_deductible_co_pay_handler(mock_deductible_co_pay_handler)
    context.mock_deductible_co_pay_handler = mock_deductible_co_pay_handler




@given("the benefit api returned a deductible {value}")
def step_benefit_api_returned_deductible(context, value):
    if value.lower() == "true":
        context.insurance_context.deductible_individual_calculated = 100
        context.insurance_context.deductible_family_calculated = 100
        context.insurance_context.accum_code = ["deductible"]
        context.insurance_context.service_amount = 100.0
        context.insurance_context.amount_copay = 0.0
        # Set default values for other required fields
        context.insurance_context.is_deductible_before_copay = False
    else:
        context.insurance_context.deductible_individual_calculated = None
        context.insurance_context.deductible_family_calculated = None
        context.insurance_context.accum_code = []
        context.insurance_context.service_amount = 100.0
        context.insurance_context.amount_copay = 0.0


@given("the deductible applies to OOPMax {value}")
def step_deductible_applies_to_oopmax(context, value):
    context.insurance_context.deductible_applies_oop = value.lower() == "true"

@given("the number of individuals needed to meet is equal to number of individuals met")
def step_individuals_needed_equals_met(context):
    """Set the number of individuals needed to meet equal to number of individuals met"""
    context.insurance_context.numOfIndividualsNeededToMeet = 2
    context.insurance_context.numOfIndividualsMet = 2

@given("the number of individuals needed to meet is not equal to number of individuals met")
def step_individuals_needed_not_equals_met(context):
    """Set the number of individuals needed to meet not equal to number of individuals met"""
    context.insurance_context.numOfIndividualsNeededToMeet = 2
    context.insurance_context.numOfIndividualsMet = 1

@then("the deductible oopmax is checked")
def step_deductible_oopmax_checked(context):
    context.mock_deductible_oopmax_handler.handle.assert_called_once_with(
        context.insurance_context
    )

@then("the deductible costshare co-pay is checked")
def step_deductible_costshare_co_pay_checked(context):
    context.mock_deductible_cost_share_co_pay_handler.handle.assert_called_once_with(
        context.insurance_context
    )

@then("the cost share co-pay is checked")
def step_cost_share_copay_checked(context):
    context.mock_cost_share_co_pay_handler.handle.assert_called_once_with(
        context.insurance_context
    )

@then("the deductible co-pay is checked")
def step_deductible_co_pay_checked(context):
    """Verify that the deductible co-pay handler was called"""
    context.mock_deductible_co_pay_handler.handle.assert_called_once_with(
        context.insurance_context
    )
