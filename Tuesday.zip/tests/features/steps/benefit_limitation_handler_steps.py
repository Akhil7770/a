from behave import given, when, then  # type: ignore
from app.services.handlers.benefit_limitation_handler import BenefitLimitationHandler
from unittest.mock import Mock


@given("a BenefitLimitationHandler is created")
def step_create_handler(context):
    # Just create the handler, don't set up mocks yet
    context.handler = BenefitLimitationHandler()


@given("an insurance context with service covered")
def step_given_service_covered_for_benefit_limitation(context):
    """Create an insurance context with service covered for benefit limitation tests"""
    from app.core.base import InsuranceContext
    context.insurance_context = InsuranceContext()
    context.insurance_context.is_service_covered = True
    # Set default values that will be overridden by specific test steps
    context.insurance_context.oopmax_individual_calculated = 0.0
    context.insurance_context.oopmax_family_calculated = 0.0
    context.insurance_context.deductible_individual_calculated = 0.0
    context.insurance_context.deductible_family_calculated = 0.0
    context.insurance_context.cost_share_copay = 0.0
    context.insurance_context.amount_coinsurance = 0.0


@given("the handler is configured with mocks")
def step_configure_handler_mocks(context):
    # Set up mocks after the insurance context exists
    mock_oopmax_handler = Mock()
    
    def mock_oopmax_handle(insurance_context):
        # Set the OOPMax values as expected by the tests
        # The tests expect these to be updated to 0 after processing
        insurance_context.oopmax_individual_calculated = 0.0
        insurance_context.oopmax_family_calculated = 0.0
        insurance_context.deductible_individual_calculated = 0.0
        insurance_context.deductible_family_calculated = 0.0
        insurance_context.cost_share_copay = 0.0
        insurance_context.amount_coinsurance = 0.0
        return insurance_context
    
    mock_oopmax_handler.handle = Mock(side_effect=mock_oopmax_handle)
    context.handler.set_oopmax_handler(mock_oopmax_handler)


@given("does not have a benefit limitation")
def step_does_not_have_benefit_limit(context):
    context.insurance_context.has_benefit_limitation = False
    context.insurance_context.accum_code = set()  # Empty set means no limit


@given("a benefit dollar limit of {limit_amount}")
def step_has_a_benefit_dollar_limit(context, limit_amount):
    context.insurance_context.limit_calculated = float(limit_amount)
    context.insurance_context.benefit_code = "limit"
    context.insurance_context.limit_type = "dollar"
    context.insurance_context.has_benefit_limitation = True
    context.insurance_context.accum_code = {"limit"}  # Set accum_code to include "limit"


@given("a benefit quantity limit of {limit_amount}")
def step_has_a_benefit_quantity_limit(context, limit_amount):
    context.insurance_context.limit_calculated = float(limit_amount)
    context.insurance_context.benefit_code = "counter"
    context.insurance_context.limit_type = "counter"
    context.insurance_context.has_benefit_limitation = True
    context.insurance_context.accum_code = {"limit"}  # Set accum_code to include "limit"


@then("now has a benefit dollar limit of {limit_amount}")
def step_now_has_a_benefit_dollar_limit(context, limit_amount):
    assert context.result.limit_calculated == float(limit_amount), f"Expected limit_calculated to be {limit_amount}, got {context.result.limit_calculated}"


# Moved to common_steps.py to avoid duplication


@then("the benefit dollar limit is updated to {limit_amount}")
def step_benefit_dollar_limit_updated(context, limit_amount):
    """Verify that the benefit dollar limit is updated to the expected value"""
    expected_limit = float(limit_amount)
    actual_limit = context.result.limit_calculated
    assert actual_limit == expected_limit, f"Expected benefit dollar limit to be {expected_limit}, but it is {actual_limit}"


@then("the benefit quantity limit is updated to {limit_amount}")
def step_benefit_quantity_limit_updated(context, limit_amount):
    """Verify that the benefit quantity limit is updated to the expected value"""
    expected_limit = float(limit_amount)
    actual_limit = context.result.limit_calculated
    assert actual_limit == expected_limit, f"Expected benefit quantity limit to be {expected_limit}, but it is {actual_limit}"


@then("the oopmax is checked")
def step_oopmax_checked(context):
    """Verify that the OOPMax handler was called"""
    context.handler._oopmax_handler.handle.assert_called_once_with(context.insurance_context)


@then("the the member co-pay is updated to {amount}")
def step_member_copay_updated(context, amount):
    """Verify that the member co-pay is updated to the expected value"""
    expected_amount = float(amount)
    actual_amount = context.result.cost_share_copay
    assert actual_amount == expected_amount, f"Expected member co-pay to be {expected_amount}, but it is {actual_amount}"


@given("the the member co-pay is {amount}")
def step_member_copay_set(context, amount):
    """Set the member co-pay amount in the insurance context"""
    context.insurance_context.cost_share_copay = float(amount)




