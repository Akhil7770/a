#!/usr/bin/env python3
"""
Test runner script for deductible mock API tests.

This script provides a convenient way to run the deductible mock API tests 
with proper configuration and output formatting.
"""

import subprocess
import sys
import os
from pathlib import Path


def run_deductible_mock_tests():
    """Run the deductible mock API tests with proper configuration."""
    
    # Get the project root directory
    project_root = Path(__file__).parent.parent
    test_file = project_root / "tests" / "api" / "test_deductible_mock_api.py"
    
    # Ensure we're in the project root for proper imports
    os.chdir(project_root)
    
    # Pytest command with appropriate flags
    cmd = [

        
        "python3", "-m", "pytest", 
        str(test_file),
        "-v",                           # Verbose output
        "-s",                           # Don't capture print statements
        "--tb=short",                   # Shorter traceback format
        "-m", "api",                    # Run only api marked tests
        "--color=yes",                  # Colored output
        "--durations=10",               # Show 10 slowest tests
        "--strict-markers",             # Fail on unknown markers
        "--no-cov"                      # Disable coverage for this run
    ]
    
    print("=" * 80)
    print("Running Deductible Mock API Tests")
    print("=" * 80)
    print(f"Test file: {test_file}")
    print(f"Working directory: {project_root}")
    print(f"Command: {' '.join(cmd)}")
    print("=" * 80)
    
    try:
        # Run the tests
        result = subprocess.run(cmd, check=False, capture_output=False)
        
        print("=" * 80)
        if result.returncode == 0:
            print("✅ All tests passed successfully!")
        else:
            print(f"❌ Tests failed with exit code: {result.returncode}")
        print("=" * 80)
        
        return result.returncode
        
    except FileNotFoundError as e:
        print(f"❌ Error: Could not find pytest. Make sure it's installed: {e}")
        return 1
    except Exception as e:
        print(f"❌ Unexpected error running tests: {e}")
        return 1


def run_specific_test_scenario(scenario: str):
    """Run a specific deductible test scenario."""
    
    project_root = Path(__file__).parent.parent
    test_file = project_root / "tests" / "api" / "test_deductible_mock_api.py"
    
    os.chdir(project_root)
    
    # Map scenario names to test methods
    scenario_tests = {
        "no_deductible": "test_no_deductible_applies_scenario",
        "parametrized": "test_all_deductible_scenarios_parametrized",
        "validation": "test_invalid_request_validation",
        "headers": "test_missing_headers_handling",
        "errors": "test_service_error_handling"
    }
    
    if scenario not in scenario_tests:
        print(f"❌ Unknown scenario: {scenario}")
        print(f"Available scenarios: {', '.join(scenario_tests.keys())}")
        return 1
    
    test_method = scenario_tests[scenario]
    
    cmd = [
        "python3", "-m", "pytest",
        f"{test_file}::TestDeductibleMockAPI::{test_method}",
        "-v", "-s", "--tb=short", "--color=yes"
    ]
    
    print(f"Running test scenario: {scenario} ({test_method})")
    print(f"Command: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, check=False, capture_output=False)
        return result.returncode
    except Exception as e:
        print(f"❌ Error running test: {e}")
        return 1


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Run specific scenario
        scenario = sys.argv[1]
        exit_code = run_specific_test_scenario(scenario)
    else:
        # Run all tests
        exit_code = run_deductible_mock_tests()
    
    sys.exit(exit_code)
