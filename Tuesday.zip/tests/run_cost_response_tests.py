#!/usr/bin/env python3
"""
Test runner for Cost Response Validation Tests

This script provides a convenient way to run the cost_response.json validation tests
with proper configuration and output formatting.
"""

import subprocess
import sys
import os
from pathlib import Path


def run_cost_response_tests():
    """Run all cost response validation tests."""
    
    # Get the project root directory
    project_root = Path(__file__).parent.parent
    test_file = project_root / "tests" / "api" / "test_cost_response_validation.py"
    
    # Ensure we're in the project root for proper imports
    os.chdir(project_root)
    
    # Pytest command with appropriate flags
    cmd = [
        "python3", "-m", "pytest", 
        str(test_file),
        "-v",                           # Verbose output
        "-s",                           # Don't capture print statements
        "--tb=short",                   # Shorter traceback format
        "-m", "api",                    # Run only api marked tests
        "--color=yes",                  # Colored output
        "--durations=10",               # Show 10 slowest tests
        "--strict-markers"              # Fail on unknown markers
    ]
    
    print("=" * 80)
    print("Running Cost Response Validation Tests")
    print("=" * 80)
    print(f"Test file: {test_file}")
    print(f"Working directory: {project_root}")
    print(f"Command: {' '.join(cmd)}")
    print("=" * 80)
    
    try:
        # Run the tests
        result = subprocess.run(cmd, check=False, capture_output=False)
        
        print("=" * 80)
        if result.returncode == 0:
            print("✅ All cost response validation tests passed successfully!")
        else:
            print(f"❌ Tests failed with exit code: {result.returncode}")
        print("=" * 80)
        
        return result.returncode
        
    except FileNotFoundError as e:
        print(f"❌ Error: Could not find python3/pytest. Make sure they're installed: {e}")
        return 1
    except Exception as e:
        print(f"❌ Unexpected error running tests: {e}")
        return 1


def run_specific_test(test_name: str):
    """Run a specific cost response validation test."""
    
    project_root = Path(__file__).parent.parent
    test_file = project_root / "tests" / "api" / "test_cost_response_validation.py"
    
    os.chdir(project_root)
    
    # Map test names to full test paths
    available_tests = {
        "structure": "TestCostResponseValidation::test_cost_response_file_structure",
        "service": "TestCostResponseValidation::test_service_section_validation",
        "provider": "TestCostResponseValidation::test_provider_info_validation",
        "coverage": "TestCostResponseValidation::test_coverage_validation",
        "cost": "TestCostResponseValidation::test_cost_validation",
        "health_claim": "TestCostResponseValidation::test_health_claim_line_validation",
        "accumulators": "TestCostResponseValidation::test_accumulators_validation",
        "deductible_acc": "TestCostResponseValidation::test_deductible_accumulators_specific_values",
        "oop_acc": "TestCostResponseValidation::test_oop_max_accumulators_specific_values",
        "json_structure": "TestCostResponseValidation::test_cost_response_json_structure_validation",
        "business_logic": "TestCostResponseValidation::test_cost_response_business_logic_validation",
        "file_exists": "TestCostResponseUtilities::test_cost_response_file_exists",
        "json_validity": "TestCostResponseUtilities::test_cost_response_json_validity"
    }
    
    if test_name not in available_tests:
        print(f"❌ Unknown test: {test_name}")
        print(f"Available tests: {', '.join(available_tests.keys())}")
        return 1
    
    test_path = available_tests[test_name]
    
    cmd = [
        "python3", "-m", "pytest",
        f"{test_file}::{test_path}",
        "-v", "-s", "--tb=short", "--color=yes"
    ]
    
    print(f"Running test: {test_name}")
    print(f"Command: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, check=False, capture_output=False)
        return result.returncode
    except Exception as e:
        print(f"❌ Error running test: {e}")
        return 1


def show_test_summary():
    """Show summary of available tests."""
    print("=" * 80)
    print("Cost Response Validation Test Summary")
    print("=" * 80)
    print("Available test categories:")
    print()
    
    test_categories = [
        ("structure", "Test basic JSON file structure"),
        ("service", "Test service section validation"),
        ("provider", "Test provider info validation"),
        ("coverage", "Test coverage section validation"),
        ("cost", "Test cost section validation"),
        ("health_claim", "Test health claim line validation"),
        ("accumulators", "Test general accumulator structure"),
        ("deductible_acc", "Test deductible accumulator specific values"),
        ("oop_acc", "Test OOP Max accumulator specific values"),
        ("json_structure", "Test JSON structure consistency"),
        ("business_logic", "Test business logic validation"),
        ("file_exists", "Test file existence and readability"),
        ("json_validity", "Test JSON validity without schema")
    ]
    
    for test_key, description in test_categories:
        print(f"  {test_key:<15} - {description}")
    
    print()
    print("Usage examples:")
    print(f"  python3 {__file__}                    # Run all tests")
    print(f"  python3 {__file__} structure          # Run structure test")
    print(f"  python3 {__file__} accumulators       # Run accumulator tests")
    print("=" * 80)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "help" or sys.argv[1] == "--help" or sys.argv[1] == "-h":
            show_test_summary()
            sys.exit(0)
        else:
            # Run specific test
            test_name = sys.argv[1]
            exit_code = run_specific_test(test_name)
    else:
        # Run all tests
        exit_code = run_cost_response_tests()
    
    sys.exit(exit_code)
